﻿Public Class Form_companion

    Private Sub Label_birthyear_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_birthmonth_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_birthmonth_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_birthday_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_birthday_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_telnumber_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_tel1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_telnumber1_TextChanged(sender As Object, e As EventArgs) Handles TextBox_telnumber1.TextChanged

    End Sub
    Private Sub TextBox_firstnamekana_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_namekanji_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_lastnamekanji_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_firstnamekanji_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_nengou_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_nengou.SelectedIndexChanged

    End Sub
    Private Sub Label_birth_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_birthyear_TextChanged(sender As Object, e As EventArgs) Handles TextBox_birthyear.TextChanged

    End Sub
    Private Sub TextBox_age_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_postalcode1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_firstname_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_age1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_age2_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_telnumber2_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_tel2_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_telnumber3_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_postalcode2_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_empnum_Click(sender As Object, e As EventArgs) Handles Label_empnum.Click

    End Sub
    Private Sub TextBox_empnum_TextChanged(sender As Object, e As EventArgs) Handles TextBox_empnum.TextChanged

    End Sub
    Private Sub Label_nowdate_Click(sender As Object, e As EventArgs) Handles Label_nowdate.Click

    End Sub
    Private Sub Label_lastupdate_Click(sender As Object, e As EventArgs) Handles Label_lastupdate.Click

    End Sub
    Private Sub Label_yomigana_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_lastname_Click(sender As Object, e As EventArgs) Handles Label_lastname.Click

    End Sub
    Private Sub TextBox_lastnamekana_TextChanged(sender As Object, e As EventArgs) Handles TextBox_lastnamekana.TextChanged

    End Sub
    Private Sub Label_postalcode2_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_address1kana_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Button_pictupload_Click(sender As Object, e As EventArgs) Handles Button_pictupload.Click

    End Sub
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
    Private Sub ComboBox_sex_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_sex.SelectedIndexChanged

    End Sub
    Private Sub Label_sex_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_Pref_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_Pref.SelectedIndexChanged

    End Sub
    Private Sub TextBox_address1kana_TextChanged(sender As Object, e As EventArgs) Handles TextBox_address1kana.TextChanged

    End Sub
    Private Sub Label_address1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_mailaddress_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_postalcode1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Button_select_Click(sender As Object, e As EventArgs) Handles Button_select.Click

    End Sub
    Private Sub Button_insert_Click(sender As Object, e As EventArgs) Handles Button_insert.Click

    End Sub
    Private Sub Button_update_Click(sender As Object, e As EventArgs) Handles Button_update.Click

    End Sub
    Private Sub Button_delete_Click(sender As Object, e As EventArgs) Handles Button_delete.Click

    End Sub
    Private Sub PictureBox_Click(sender As Object, e As EventArgs) Handles PictureBox.Click

    End Sub
    Private Sub TextBox_Company_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Company.TextChanged

    End Sub
    Private Sub Label_company_Click(sender As Object, e As EventArgs) Handles Label_company.Click

    End Sub
    Private Sub TextBox_retire_TextChanged(sender As Object, e As EventArgs) Handles TextBox_retire.TextChanged

    End Sub
    Private Sub TextBox_address1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_joindate_TextChanged(sender As Object, e As EventArgs) Handles TextBox_joindate.TextChanged

    End Sub
    Private Sub Label_joindate_Click(sender As Object, e As EventArgs) Handles Label_joindate.Click

    End Sub
    Private Sub TextBox_belong_TextChanged(sender As Object, e As EventArgs) Handles TextBox_belong.TextChanged

    End Sub
    Private Sub Label_belong_Click(sender As Object, e As EventArgs) Handles Label_belong.Click

    End Sub
    Private Sub Label_retire_Click(sender As Object, e As EventArgs) Handles Label_retire.Click

    End Sub
    Private Sub Button_pictselect_Click(sender As Object, e As EventArgs) Handles Button_pictselect.Click

    End Sub
    Private Sub Label11_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label10_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label12_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox5_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label13_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox6_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub
    Private Sub Label21_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox9_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label20_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label19_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox19_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox8_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label18_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label17_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label16_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox18_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label15_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox7_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label14_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox15_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs) Handles TextBox13.TextChanged

    End Sub
    Private Sub Label29_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox12_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label28_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label27_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox26_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox11_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label26_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label25_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label24_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox25_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label23_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox10_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label22_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox24_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox23_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox22_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox21_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox20_TextChanged(sender As Object, e As EventArgs) Handles TextBox20.TextChanged

    End Sub
    Private Sub Label37_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox15_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label36_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label35_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox33_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox14_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label34_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label33_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label32_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox32_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label31_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox13_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label30_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox31_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox30_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox29_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox28_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox27_TextChanged(sender As Object, e As EventArgs) Handles TextBox27.TextChanged

    End Sub
    Private Sub Label45_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox18_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label44_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label43_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox39_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox17_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label42_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label41_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label40_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox38_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label39_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox16_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label38_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox37_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox36_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox35_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox34_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label53_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox21_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label52_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label51_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox45_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox20_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label50_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label49_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub GroupBox_dependents_Enter(sender As Object, e As EventArgs) Handles GroupBox_dependents.Enter

    End Sub
    Private Sub Label47_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_address2_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label48_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox44_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox19_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label46_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox43_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub GroupBox_bankinfo_Enter(sender As Object, e As EventArgs) Handles GroupBox_bankinfo.Enter

    End Sub
    Private Sub TextBox_address2kana_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_address2kana_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox42_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox41_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox40_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox46_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox47_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox48_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox49_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox50_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox51_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_address2_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_pref_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_bankname_Click(sender As Object, e As EventArgs) Handles Label_bankname.Click

    End Sub
    Private Sub TextBox_bankname_TextChanged(sender As Object, e As EventArgs) Handles TextBox_bankname.TextChanged

    End Sub
    Private Sub Label_branchname_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_branchname_TextChanged(sender As Object, e As EventArgs) Handles TextBox_branchname.TextChanged

    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
    Private Sub Label_accounttype_Click(sender As Object, e As EventArgs) Handles Label_accounttype.Click

    End Sub
    Private Sub Label_accountnumber_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
    Private Sub Label_dependentsfirstname_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_dependentlastname_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_dependentslastnamekana1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_dependentsfirstnamekana1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_dependentsbirth_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_dependentsnengou1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label9_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label8_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_relation1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_dependentsnamekana1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub Label_dependentsname1_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_dependentslastnamekanji1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub TextBox_dependentsfirstnamekanji1_TextChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub ComboBox_dependents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_dependents.SelectedIndexChanged

    End Sub
    Private Sub Label_dependents_Click(sender As Object, e As EventArgs) Handles Label_dependents.Click

    End Sub
    Private Sub Label54_Click(sender As Object, e As EventArgs) Handles Label54.Click

    End Sub
    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub
    Private Sub RichTextBox2_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox2.TextChanged

    End Sub
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label57_Click(sender As Object, e As EventArgs) Handles Label57.Click

    End Sub

    Private Sub Label58_Click(sender As Object, e As EventArgs) Handles Label58.Click

    End Sub

    Private Sub Form_companion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label14_Click_1(sender As Object, e As EventArgs) Handles Label14.Click

    End Sub
End Class