﻿Public Class Form_staff

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button_delete_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button_update_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button_insert_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label__Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_lastnamekana_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox_nengou_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_birthyear_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_birthyear_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_birthday_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_namekanji_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_lastnamekanji_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_yomigana_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_lastname_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_lastnamekana_TextChanged_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_firstnamekanji_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox_firstnamekana_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_firstname_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label_birthday_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Button_pictselect_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button_pictupload_Click(sender As Object, e As EventArgs)

    End Sub
End Class
