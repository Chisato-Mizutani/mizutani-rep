﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_staff
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_staff))
        Me.ComboBox39 = New System.Windows.Forms.ComboBox()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.ComboBox38 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.ComboBox36 = New System.Windows.Forms.ComboBox()
        Me.ComboBox31 = New System.Windows.Forms.ComboBox()
        Me.TextBox79 = New System.Windows.Forms.TextBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox86 = New System.Windows.Forms.TextBox()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.TextBox87 = New System.Windows.Forms.TextBox()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.TextBox90 = New System.Windows.Forms.TextBox()
        Me.ComboBox32 = New System.Windows.Forms.ComboBox()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.ComboBox35 = New System.Windows.Forms.ComboBox()
        Me.ComboBox34 = New System.Windows.Forms.ComboBox()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.ComboBox33 = New System.Windows.Forms.ComboBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label_dependents = New System.Windows.Forms.Label()
        Me.ComboBox_dependents = New System.Windows.Forms.ComboBox()
        Me.Button_pictselect = New System.Windows.Forms.Button()
        Me.Label_retire = New System.Windows.Forms.Label()
        Me.Label_belong = New System.Windows.Forms.Label()
        Me.TextBox_belong = New System.Windows.Forms.TextBox()
        Me.Label_joindate = New System.Windows.Forms.Label()
        Me.Label_company = New System.Windows.Forms.Label()
        Me.TextBox_Company = New System.Windows.Forms.TextBox()
        Me.PictureBox = New System.Windows.Forms.PictureBox()
        Me.Label_nowdate = New System.Windows.Forms.Label()
        Me.TextBox_empnum = New System.Windows.Forms.TextBox()
        Me.TextBox_address1kana = New System.Windows.Forms.TextBox()
        Me.ComboBox_Pref = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button_pictupload = New System.Windows.Forms.Button()
        Me.Label_empnum = New System.Windows.Forms.Label()
        Me.TextBox_birthyear = New System.Windows.Forms.TextBox()
        Me.ComboBox_nengou = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox88 = New System.Windows.Forms.TextBox()
        Me.TextBox89 = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.ComboBox_sex = New System.Windows.Forms.ComboBox()
        Me.GroupBox_dependents = New System.Windows.Forms.GroupBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.ComboBox27 = New System.Windows.Forms.ComboBox()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.ComboBox28 = New System.Windows.Forms.ComboBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.TextBox74 = New System.Windows.Forms.TextBox()
        Me.ComboBox29 = New System.Windows.Forms.ComboBox()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.ComboBox30 = New System.Windows.Forms.ComboBox()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.TextBox80 = New System.Windows.Forms.TextBox()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.ComboBox22 = New System.Windows.Forms.ComboBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.ComboBox26 = New System.Windows.Forms.ComboBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox85 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox_branchname = New System.Windows.Forms.TextBox()
        Me.TextBox_bankname = New System.Windows.Forms.TextBox()
        Me.Label_bankname = New System.Windows.Forms.Label()
        Me.Label_accounttype = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.TextBox78 = New System.Windows.Forms.TextBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.GroupBox_bankinfo = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button_delete = New System.Windows.Forms.Button()
        Me.Button_update = New System.Windows.Forms.Button()
        Me.Button_insert = New System.Windows.Forms.Button()
        Me.Button_select = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox_dependents.SuspendLayout()
        Me.GroupBox_bankinfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBox39
        '
        Me.ComboBox39.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox39.FormattingEnabled = True
        Me.ComboBox39.Location = New System.Drawing.Point(245, 189)
        Me.ComboBox39.Name = "ComboBox39"
        Me.ComboBox39.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox39.TabIndex = 355
        Me.ComboBox39.Text = "12"
        '
        'Label114
        '
        Me.Label114.AccessibleName = "-"
        Me.Label114.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label114.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label114.Location = New System.Drawing.Point(141, 603)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(84, 21)
        Me.Label114.TabIndex = 353
        Me.Label114.Text = "扶養義務"
        Me.Label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox38
        '
        Me.ComboBox38.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox38.FormattingEnabled = True
        Me.ComboBox38.Location = New System.Drawing.Point(232, 604)
        Me.ComboBox38.Name = "ComboBox38"
        Me.ComboBox38.Size = New System.Drawing.Size(47, 21)
        Me.ComboBox38.TabIndex = 352
        Me.ComboBox38.Text = "無し"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label135)
        Me.GroupBox2.Controls.Add(Me.ComboBox36)
        Me.GroupBox2.Controls.Add(Me.ComboBox31)
        Me.GroupBox2.Controls.Add(Me.TextBox79)
        Me.GroupBox2.Controls.Add(Me.Label117)
        Me.GroupBox2.Controls.Add(Me.Label120)
        Me.GroupBox2.Controls.Add(Me.TextBox65)
        Me.GroupBox2.Controls.Add(Me.TextBox86)
        Me.GroupBox2.Controls.Add(Me.Label119)
        Me.GroupBox2.Controls.Add(Me.TextBox59)
        Me.GroupBox2.Controls.Add(Me.Label123)
        Me.GroupBox2.Controls.Add(Me.TextBox87)
        Me.GroupBox2.Controls.Add(Me.Label125)
        Me.GroupBox2.Controls.Add(Me.TextBox90)
        Me.GroupBox2.Controls.Add(Me.ComboBox32)
        Me.GroupBox2.Controls.Add(Me.Label121)
        Me.GroupBox2.Controls.Add(Me.Label126)
        Me.GroupBox2.Controls.Add(Me.Label122)
        Me.GroupBox2.Controls.Add(Me.Label127)
        Me.GroupBox2.Controls.Add(Me.Label124)
        Me.GroupBox2.Controls.Add(Me.TextBox66)
        Me.GroupBox2.Controls.Add(Me.Label129)
        Me.GroupBox2.Controls.Add(Me.ComboBox35)
        Me.GroupBox2.Controls.Add(Me.ComboBox34)
        Me.GroupBox2.Controls.Add(Me.Label139)
        Me.GroupBox2.Controls.Add(Me.Label118)
        Me.GroupBox2.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.GroupBox2.Location = New System.Drawing.Point(17, 628)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(536, 115)
        Me.GroupBox2.TabIndex = 308
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "配偶者情報"
        '
        'Label135
        '
        Me.Label135.AccessibleName = "-"
        Me.Label135.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label135.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label135.Location = New System.Drawing.Point(19, 86)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(64, 21)
        Me.Label135.TabIndex = 636
        Me.Label135.Text = "性別"
        Me.Label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox36
        '
        Me.ComboBox36.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox36.FormattingEnabled = True
        Me.ComboBox36.Location = New System.Drawing.Point(89, 86)
        Me.ComboBox36.Name = "ComboBox36"
        Me.ComboBox36.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox36.TabIndex = 635
        Me.ComboBox36.Text = "男性"
        '
        'ComboBox31
        '
        Me.ComboBox31.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Location = New System.Drawing.Point(198, 62)
        Me.ComboBox31.Name = "ComboBox31"
        Me.ComboBox31.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox31.TabIndex = 645
        Me.ComboBox31.Text = "12"
        '
        'TextBox79
        '
        Me.TextBox79.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox79.Location = New System.Drawing.Point(114, 39)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(190, 21)
        Me.TextBox79.TabIndex = 642
        Me.TextBox79.Text = "古屋敷"
        '
        'Label117
        '
        Me.Label117.AccessibleName = "-"
        Me.Label117.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label117.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label117.Location = New System.Drawing.Point(450, 62)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(20, 21)
        Me.Label117.TabIndex = 644
        Me.Label117.Text = "歳"
        Me.Label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label120
        '
        Me.Label120.AccessibleName = "-"
        Me.Label120.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label120.Location = New System.Drawing.Point(150, 87)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(90, 21)
        Me.Label120.TabIndex = 181
        Me.Label120.Text = "マイナンバー"
        Me.Label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox65
        '
        Me.TextBox65.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox65.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox65.Location = New System.Drawing.Point(414, 62)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(32, 21)
        Me.TextBox65.TabIndex = 643
        Me.TextBox65.Text = "28"
        Me.TextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox86
        '
        Me.TextBox86.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox86.Location = New System.Drawing.Point(89, 17)
        Me.TextBox86.Name = "TextBox86"
        Me.TextBox86.Size = New System.Drawing.Size(215, 21)
        Me.TextBox86.TabIndex = 641
        Me.TextBox86.Text = "フルヤシキ"
        '
        'Label119
        '
        Me.Label119.AccessibleName = "-"
        Me.Label119.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label119.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label119.Location = New System.Drawing.Point(336, 62)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(50, 21)
        Me.Label119.TabIndex = 642
        Me.Label119.Text = "年齢"
        Me.Label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(245, 87)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(86, 21)
        Me.TextBox59.TabIndex = 180
        Me.TextBox59.Text = "12345678901"
        '
        'Label123
        '
        Me.Label123.AccessibleName = "-"
        Me.Label123.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label123.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label123.Location = New System.Drawing.Point(390, 62)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(20, 21)
        Me.Label123.TabIndex = 641
        Me.Label123.Text = "満"
        Me.Label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox87
        '
        Me.TextBox87.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox87.Location = New System.Drawing.Point(335, 39)
        Me.TextBox87.Name = "TextBox87"
        Me.TextBox87.Size = New System.Drawing.Size(190, 21)
        Me.TextBox87.TabIndex = 640
        Me.TextBox87.Text = "後部屋新九郎左衛門介之亟"
        '
        'Label125
        '
        Me.Label125.AccessibleName = "-"
        Me.Label125.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label125.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label125.Location = New System.Drawing.Point(310, 62)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(20, 21)
        Me.Label125.TabIndex = 640
        Me.Label125.Text = "日"
        Me.Label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox90
        '
        Me.TextBox90.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox90.Location = New System.Drawing.Point(310, 17)
        Me.TextBox90.Name = "TextBox90"
        Me.TextBox90.Size = New System.Drawing.Size(215, 21)
        Me.TextBox90.TabIndex = 639
        Me.TextBox90.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'ComboBox32
        '
        Me.ComboBox32.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox32.FormattingEnabled = True
        Me.ComboBox32.Location = New System.Drawing.Point(265, 62)
        Me.ComboBox32.Name = "ComboBox32"
        Me.ComboBox32.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox32.TabIndex = 639
        Me.ComboBox32.Text = "12"
        '
        'Label121
        '
        Me.Label121.AccessibleName = "-"
        Me.Label121.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label121.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label121.Location = New System.Drawing.Point(89, 39)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(20, 21)
        Me.Label121.TabIndex = 635
        Me.Label121.Text = "姓"
        Me.Label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label126
        '
        Me.Label126.AccessibleName = "-"
        Me.Label126.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label126.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label126.Location = New System.Drawing.Point(240, 62)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(20, 21)
        Me.Label126.TabIndex = 638
        Me.Label126.Text = "月"
        Me.Label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label122
        '
        Me.Label122.AccessibleName = "-"
        Me.Label122.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label122.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label122.Location = New System.Drawing.Point(19, 39)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(64, 21)
        Me.Label122.TabIndex = 637
        Me.Label122.Text = "氏名"
        Me.Label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label127
        '
        Me.Label127.AccessibleName = "-"
        Me.Label127.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label127.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label127.Location = New System.Drawing.Point(173, 62)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(20, 21)
        Me.Label127.TabIndex = 637
        Me.Label127.Text = "年"
        Me.Label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label124
        '
        Me.Label124.AccessibleName = "-"
        Me.Label124.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label124.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label124.Location = New System.Drawing.Point(310, 39)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(20, 21)
        Me.Label124.TabIndex = 638
        Me.Label124.Text = "名"
        Me.Label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox66
        '
        Me.TextBox66.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox66.Location = New System.Drawing.Point(143, 62)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(25, 21)
        Me.TextBox66.TabIndex = 636
        Me.TextBox66.Text = "61"
        '
        'Label129
        '
        Me.Label129.AccessibleName = "-"
        Me.Label129.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label129.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label129.Location = New System.Drawing.Point(19, 17)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(64, 21)
        Me.Label129.TabIndex = 636
        Me.Label129.Text = "フリガナ"
        Me.Label129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox35
        '
        Me.ComboBox35.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox35.FormattingEnabled = True
        Me.ComboBox35.Location = New System.Drawing.Point(89, 62)
        Me.ComboBox35.Name = "ComboBox35"
        Me.ComboBox35.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox35.TabIndex = 635
        Me.ComboBox35.Text = "昭和"
        '
        'ComboBox34
        '
        Me.ComboBox34.FormattingEnabled = True
        Me.ComboBox34.Location = New System.Drawing.Point(455, 37)
        Me.ComboBox34.Name = "ComboBox34"
        Me.ComboBox34.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox34.TabIndex = 413
        '
        'Label139
        '
        Me.Label139.AccessibleName = "-"
        Me.Label139.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label139.Location = New System.Drawing.Point(19, 62)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(64, 21)
        Me.Label139.TabIndex = 576
        Me.Label139.Text = "生年月日"
        Me.Label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label118
        '
        Me.Label118.AccessibleName = "-"
        Me.Label118.Location = New System.Drawing.Point(394, 38)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(56, 19)
        Me.Label118.TabIndex = 412
        Me.Label118.Text = "性別"
        Me.Label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label115
        '
        Me.Label115.AccessibleName = "-"
        Me.Label115.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label115.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label115.Location = New System.Drawing.Point(17, 603)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(61, 21)
        Me.Label115.TabIndex = 350
        Me.Label115.Text = "配偶者"
        Me.Label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox33
        '
        Me.ComboBox33.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox33.FormattingEnabled = True
        Me.ComboBox33.Location = New System.Drawing.Point(84, 604)
        Me.ComboBox33.Name = "ComboBox33"
        Me.ComboBox33.Size = New System.Drawing.Size(47, 21)
        Me.ComboBox33.TabIndex = 349
        Me.ComboBox33.Text = "有り"
        '
        'TextBox51
        '
        Me.TextBox51.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox51.Location = New System.Drawing.Point(180, 335)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(40, 21)
        Me.TextBox51.TabIndex = 347
        Me.TextBox51.Text = "8585"
        '
        'TextBox50
        '
        Me.TextBox50.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox50.Location = New System.Drawing.Point(196, 285)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(50, 21)
        Me.TextBox50.TabIndex = 346
        Me.TextBox50.Text = "1234"
        '
        'Label15
        '
        Me.Label15.AccessibleName = "-"
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label15.Location = New System.Drawing.Point(549, 189)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(20, 21)
        Me.Label15.TabIndex = 345
        Me.Label15.Text = "歳"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox8.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox8.Location = New System.Drawing.Point(509, 189)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(35, 21)
        Me.TextBox8.TabIndex = 344
        Me.TextBox8.Text = "28"
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AccessibleName = "-"
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label14.Location = New System.Drawing.Point(409, 189)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(70, 21)
        Me.Label14.TabIndex = 343
        Me.Label14.Text = "年齢"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.AccessibleName = "-"
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label13.Location = New System.Drawing.Point(484, 189)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(20, 21)
        Me.Label13.TabIndex = 342
        Me.Label13.Text = "満"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox63
        '
        Me.TextBox63.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox63.Location = New System.Drawing.Point(115, 455)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(420, 21)
        Me.TextBox63.TabIndex = 341
        Me.TextBox63.Text = "ロイヤル県庁マンション505号室"
        '
        'TextBox64
        '
        Me.TextBox64.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox64.Location = New System.Drawing.Point(115, 431)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(420, 21)
        Me.TextBox64.TabIndex = 340
        Me.TextBox64.Text = "ロイヤルケンチョウマンション505ゴウシツ"
        '
        'Label75
        '
        Me.Label75.AccessibleName = "-"
        Me.Label75.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label75.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label75.Location = New System.Drawing.Point(17, 455)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(90, 21)
        Me.Label75.TabIndex = 339
        Me.Label75.Text = "住所２"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label76
        '
        Me.Label76.AccessibleName = "-"
        Me.Label76.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label76.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label76.Location = New System.Drawing.Point(17, 431)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(90, 21)
        Me.Label76.TabIndex = 338
        Me.Label76.Text = "フリガナ"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox62
        '
        Me.TextBox62.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox62.Location = New System.Drawing.Point(115, 407)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(342, 21)
        Me.TextBox62.TabIndex = 337
        Me.TextBox62.Text = "和歌山市小松原通1丁目1番地"
        '
        'Label74
        '
        Me.Label74.AccessibleName = "-"
        Me.Label74.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label74.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label74.Location = New System.Drawing.Point(17, 407)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(90, 21)
        Me.Label74.TabIndex = 336
        Me.Label74.Text = "住所１"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label73
        '
        Me.Label73.AccessibleName = "-"
        Me.Label73.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label73.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label73.Location = New System.Drawing.Point(17, 383)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(90, 21)
        Me.Label73.TabIndex = 335
        Me.Label73.Text = "フリガナ"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label72
        '
        Me.Label72.AccessibleName = "-"
        Me.Label72.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label72.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label72.Location = New System.Drawing.Point(17, 359)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(90, 21)
        Me.Label72.TabIndex = 334
        Me.Label72.Text = "都道府県"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label71
        '
        Me.Label71.AccessibleName = "-"
        Me.Label71.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label71.Location = New System.Drawing.Point(155, 335)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(20, 21)
        Me.Label71.TabIndex = 333
        Me.Label71.Text = "-"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox61
        '
        Me.TextBox61.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox61.Location = New System.Drawing.Point(115, 335)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(35, 21)
        Me.TextBox61.TabIndex = 332
        Me.TextBox61.Text = "640"
        '
        'Label70
        '
        Me.Label70.AccessibleName = "-"
        Me.Label70.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label70.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label70.Location = New System.Drawing.Point(17, 335)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(90, 21)
        Me.Label70.TabIndex = 331
        Me.Label70.Text = "郵便番号"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label68
        '
        Me.Label68.AccessibleName = "-"
        Me.Label68.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label68.Location = New System.Drawing.Point(251, 285)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(20, 21)
        Me.Label68.TabIndex = 329
        Me.Label68.Text = "-"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label67
        '
        Me.Label67.AccessibleName = "-"
        Me.Label67.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label67.Location = New System.Drawing.Point(170, 285)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(20, 21)
        Me.Label67.TabIndex = 328
        Me.Label67.Text = "-"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label66
        '
        Me.Label66.AccessibleName = "-"
        Me.Label66.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label66.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label66.Location = New System.Drawing.Point(17, 285)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(90, 21)
        Me.Label66.TabIndex = 327
        Me.Label66.Text = "電話番号"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label65
        '
        Me.Label65.AccessibleName = "-"
        Me.Label65.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label65.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label65.Location = New System.Drawing.Point(375, 189)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(20, 21)
        Me.Label65.TabIndex = 326
        Me.Label65.Text = "日"
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label69
        '
        Me.Label69.AccessibleName = "-"
        Me.Label69.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label69.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label69.Location = New System.Drawing.Point(17, 310)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(90, 21)
        Me.Label69.TabIndex = 330
        Me.Label69.Text = "メールアドレス"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.AccessibleName = "-"
        Me.Label64.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label64.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label64.Location = New System.Drawing.Point(295, 189)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(20, 21)
        Me.Label64.TabIndex = 324
        Me.Label64.Text = "月"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label63
        '
        Me.Label63.AccessibleName = "-"
        Me.Label63.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label63.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label63.Location = New System.Drawing.Point(215, 189)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(20, 21)
        Me.Label63.TabIndex = 323
        Me.Label63.Text = "年"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label62
        '
        Me.Label62.AccessibleName = "-"
        Me.Label62.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label62.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label62.Location = New System.Drawing.Point(17, 189)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(90, 21)
        Me.Label62.TabIndex = 322
        Me.Label62.Text = "生年月日"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RichTextBox2)
        Me.GroupBox1.Location = New System.Drawing.Point(17, 875)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1295, 120)
        Me.GroupBox1.TabIndex = 307
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "更新履歴"
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RichTextBox2.Location = New System.Drawing.Point(8, 15)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(1280, 100)
        Me.RichTextBox2.TabIndex = 106
        Me.RichTextBox2.Text = resources.GetString("RichTextBox2.Text")
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.RichTextBox1.Location = New System.Drawing.Point(17, 777)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1295, 95)
        Me.RichTextBox1.TabIndex = 304
        Me.RichTextBox1.Text = "寿限無、寿限無" & Global.Microsoft.VisualBasic.ChrW(10) & "五劫の擦り切れ" & Global.Microsoft.VisualBasic.ChrW(10) & "海砂利水魚の" & Global.Microsoft.VisualBasic.ChrW(10) & "水行末 雲来末 風来末" & Global.Microsoft.VisualBasic.ChrW(10) & "食う寝る処に住む処" & Global.Microsoft.VisualBasic.ChrW(10) & "藪ら柑子の藪柑子" & Global.Microsoft.VisualBasic.ChrW(10) & "パイポパイポ パイポのシューリンガン" & Global.Microsoft.VisualBasic.ChrW(10) & "シューリンガンの" & _
    "グーリンダイ" & Global.Microsoft.VisualBasic.ChrW(10) & "グーリンダイのポンポコピーのポンポコナーの" & Global.Microsoft.VisualBasic.ChrW(10) & "長久命の長助"
        '
        'Label54
        '
        Me.Label54.AccessibleName = "-"
        Me.Label54.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label54.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label54.Location = New System.Drawing.Point(17, 755)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(40, 21)
        Me.Label54.TabIndex = 303
        Me.Label54.Text = "備考"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_dependents
        '
        Me.Label_dependents.AccessibleName = "-"
        Me.Label_dependents.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_dependents.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_dependents.Location = New System.Drawing.Point(574, 189)
        Me.Label_dependents.Name = "Label_dependents"
        Me.Label_dependents.Size = New System.Drawing.Size(75, 21)
        Me.Label_dependents.TabIndex = 302
        Me.Label_dependents.Text = "扶養家族"
        Me.Label_dependents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_dependents
        '
        Me.ComboBox_dependents.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox_dependents.FormattingEnabled = True
        Me.ComboBox_dependents.Location = New System.Drawing.Point(654, 189)
        Me.ComboBox_dependents.Name = "ComboBox_dependents"
        Me.ComboBox_dependents.Size = New System.Drawing.Size(47, 21)
        Me.ComboBox_dependents.TabIndex = 300
        Me.ComboBox_dependents.Text = "有り"
        '
        'Button_pictselect
        '
        Me.Button_pictselect.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_pictselect.Location = New System.Drawing.Point(1145, 193)
        Me.Button_pictselect.Name = "Button_pictselect"
        Me.Button_pictselect.Size = New System.Drawing.Size(80, 23)
        Me.Button_pictselect.TabIndex = 285
        Me.Button_pictselect.Text = "画像選択"
        Me.Button_pictselect.UseVisualStyleBackColor = True
        '
        'Label_retire
        '
        Me.Label_retire.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_retire.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_retire.Location = New System.Drawing.Point(931, 55)
        Me.Label_retire.Name = "Label_retire"
        Me.Label_retire.Size = New System.Drawing.Size(76, 19)
        Me.Label_retire.TabIndex = 284
        Me.Label_retire.Text = "退職日"
        Me.Label_retire.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_belong
        '
        Me.Label_belong.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_belong.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_belong.Location = New System.Drawing.Point(436, 55)
        Me.Label_belong.Name = "Label_belong"
        Me.Label_belong.Size = New System.Drawing.Size(76, 19)
        Me.Label_belong.TabIndex = 282
        Me.Label_belong.Text = "所属部署"
        Me.Label_belong.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_belong
        '
        Me.TextBox_belong.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox_belong.Location = New System.Drawing.Point(436, 76)
        Me.TextBox_belong.Name = "TextBox_belong"
        Me.TextBox_belong.Size = New System.Drawing.Size(192, 21)
        Me.TextBox_belong.TabIndex = 281
        Me.TextBox_belong.Text = "デベロップ課"
        '
        'Label_joindate
        '
        Me.Label_joindate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_joindate.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_joindate.Location = New System.Drawing.Point(798, 55)
        Me.Label_joindate.Name = "Label_joindate"
        Me.Label_joindate.Size = New System.Drawing.Size(76, 19)
        Me.Label_joindate.TabIndex = 280
        Me.Label_joindate.Text = "入社日"
        Me.Label_joindate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_company
        '
        Me.Label_company.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_company.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_company.Location = New System.Drawing.Point(17, 55)
        Me.Label_company.Name = "Label_company"
        Me.Label_company.Size = New System.Drawing.Size(76, 19)
        Me.Label_company.TabIndex = 278
        Me.Label_company.Text = "会社名"
        Me.Label_company.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_Company
        '
        Me.TextBox_Company.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox_Company.Location = New System.Drawing.Point(17, 76)
        Me.TextBox_Company.Name = "TextBox_Company"
        Me.TextBox_Company.Size = New System.Drawing.Size(399, 21)
        Me.TextBox_Company.TabIndex = 277
        Me.TextBox_Company.Text = "株式会社アップワードホールディングス"
        '
        'PictureBox
        '
        Me.PictureBox.Location = New System.Drawing.Point(1146, 50)
        Me.PictureBox.Name = "PictureBox"
        Me.PictureBox.Size = New System.Drawing.Size(164, 140)
        Me.PictureBox.TabIndex = 276
        Me.PictureBox.TabStop = False
        '
        'Label_nowdate
        '
        Me.Label_nowdate.AccessibleName = "-"
        Me.Label_nowdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_nowdate.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_nowdate.Location = New System.Drawing.Point(968, 17)
        Me.Label_nowdate.Name = "Label_nowdate"
        Me.Label_nowdate.Size = New System.Drawing.Size(95, 23)
        Me.Label_nowdate.TabIndex = 289
        Me.Label_nowdate.Text = "2015/10/10"
        Me.Label_nowdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox_empnum
        '
        Me.TextBox_empnum.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox_empnum.Location = New System.Drawing.Point(675, 76)
        Me.TextBox_empnum.Name = "TextBox_empnum"
        Me.TextBox_empnum.Size = New System.Drawing.Size(76, 21)
        Me.TextBox_empnum.TabIndex = 287
        Me.TextBox_empnum.Text = "123456"
        '
        'TextBox_address1kana
        '
        Me.TextBox_address1kana.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox_address1kana.Location = New System.Drawing.Point(115, 383)
        Me.TextBox_address1kana.Name = "TextBox_address1kana"
        Me.TextBox_address1kana.Size = New System.Drawing.Size(342, 21)
        Me.TextBox_address1kana.TabIndex = 299
        Me.TextBox_address1kana.Text = "ワカヤマシコマツバラドオリ1チョウメ1バンチ"
        '
        'ComboBox_Pref
        '
        Me.ComboBox_Pref.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox_Pref.FormattingEnabled = True
        Me.ComboBox_Pref.Location = New System.Drawing.Point(115, 359)
        Me.ComboBox_Pref.Name = "ComboBox_Pref"
        Me.ComboBox_Pref.Size = New System.Drawing.Size(112, 21)
        Me.ComboBox_Pref.TabIndex = 298
        Me.ComboBox_Pref.Text = "和歌山県"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox1.Location = New System.Drawing.Point(115, 309)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(419, 21)
        Me.TextBox1.TabIndex = 296
        Me.TextBox1.Text = "abcdefghijklmnopqrstuvwxyz-12.34_567890@hogehoge.ne.jp"
        '
        'Button_pictupload
        '
        Me.Button_pictupload.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_pictupload.Location = New System.Drawing.Point(1232, 193)
        Me.Button_pictupload.Name = "Button_pictupload"
        Me.Button_pictupload.Size = New System.Drawing.Size(80, 23)
        Me.Button_pictupload.TabIndex = 286
        Me.Button_pictupload.Text = "アップロード"
        Me.Button_pictupload.UseVisualStyleBackColor = True
        '
        'Label_empnum
        '
        Me.Label_empnum.AccessibleName = "-"
        Me.Label_empnum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_empnum.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label_empnum.Location = New System.Drawing.Point(675, 55)
        Me.Label_empnum.Name = "Label_empnum"
        Me.Label_empnum.Size = New System.Drawing.Size(76, 19)
        Me.Label_empnum.TabIndex = 288
        Me.Label_empnum.Text = "社員番号"
        Me.Label_empnum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_birthyear
        '
        Me.TextBox_birthyear.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox_birthyear.Location = New System.Drawing.Point(175, 189)
        Me.TextBox_birthyear.Name = "TextBox_birthyear"
        Me.TextBox_birthyear.Size = New System.Drawing.Size(35, 21)
        Me.TextBox_birthyear.TabIndex = 294
        Me.TextBox_birthyear.Text = "61"
        Me.TextBox_birthyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ComboBox_nengou
        '
        Me.ComboBox_nengou.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox_nengou.FormattingEnabled = True
        Me.ComboBox_nengou.Location = New System.Drawing.Point(115, 189)
        Me.ComboBox_nengou.Name = "ComboBox_nengou"
        Me.ComboBox_nengou.Size = New System.Drawing.Size(56, 21)
        Me.ComboBox_nengou.TabIndex = 293
        Me.ComboBox_nengou.Text = "昭和"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label128)
        Me.GroupBox3.Controls.Add(Me.TextBox70)
        Me.GroupBox3.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.GroupBox3.Location = New System.Drawing.Point(17, 228)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(249, 46)
        Me.GroupBox3.TabIndex = 306
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "その他個人情報"
        '
        'Label128
        '
        Me.Label128.AccessibleName = "-"
        Me.Label128.Location = New System.Drawing.Point(6, 17)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(98, 21)
        Me.Label128.TabIndex = 179
        Me.Label128.Text = "マイナンバー"
        Me.Label128.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox70
        '
        Me.TextBox70.Location = New System.Drawing.Point(113, 17)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(116, 21)
        Me.TextBox70.TabIndex = 178
        Me.TextBox70.Text = "12345678901"
        '
        'Label55
        '
        Me.Label55.AccessibleName = "-"
        Me.Label55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label55.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label55.Location = New System.Drawing.Point(854, 17)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(95, 23)
        Me.Label55.TabIndex = 356
        Me.Label55.Text = "当日の日付"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label57
        '
        Me.Label57.AccessibleName = "-"
        Me.Label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label57.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label57.Location = New System.Drawing.Point(1101, 17)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(95, 23)
        Me.Label57.TabIndex = 357
        Me.Label57.Text = "最終更新日時"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AccessibleName = "-"
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label7.Location = New System.Drawing.Point(1215, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 23)
        Me.Label7.TabIndex = 364
        Me.Label7.Text = "2015/10/10"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox88
        '
        Me.TextBox88.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox88.Location = New System.Drawing.Point(360, 133)
        Me.TextBox88.Name = "TextBox88"
        Me.TextBox88.Size = New System.Drawing.Size(190, 21)
        Me.TextBox88.TabIndex = 621
        Me.TextBox88.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox89
        '
        Me.TextBox89.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox89.Location = New System.Drawing.Point(335, 109)
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.Size = New System.Drawing.Size(215, 21)
        Me.TextBox89.TabIndex = 620
        Me.TextBox89.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label56
        '
        Me.Label56.AccessibleName = "-"
        Me.Label56.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label56.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label56.Location = New System.Drawing.Point(115, 133)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(20, 21)
        Me.Label56.TabIndex = 616
        Me.Label56.Text = "姓"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label59
        '
        Me.Label59.AccessibleName = "-"
        Me.Label59.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label59.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label59.Location = New System.Drawing.Point(17, 133)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(90, 21)
        Me.Label59.TabIndex = 618
        Me.Label59.Text = "氏名"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label60
        '
        Me.Label60.AccessibleName = "-"
        Me.Label60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label60.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label60.Location = New System.Drawing.Point(335, 133)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(20, 21)
        Me.Label60.TabIndex = 619
        Me.Label60.Text = "名"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label141
        '
        Me.Label141.AccessibleName = "-"
        Me.Label141.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label141.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label141.Location = New System.Drawing.Point(17, 109)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(90, 21)
        Me.Label141.TabIndex = 617
        Me.Label141.Text = "フリガナ"
        Me.Label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label61
        '
        Me.Label61.AccessibleName = "-"
        Me.Label61.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label61.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label61.Location = New System.Drawing.Point(17, 157)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(90, 21)
        Me.Label61.TabIndex = 625
        Me.Label61.Text = "性別"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_sex
        '
        Me.ComboBox_sex.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox_sex.FormattingEnabled = True
        Me.ComboBox_sex.Location = New System.Drawing.Point(115, 157)
        Me.ComboBox_sex.Name = "ComboBox_sex"
        Me.ComboBox_sex.Size = New System.Drawing.Size(56, 21)
        Me.ComboBox_sex.TabIndex = 624
        Me.ComboBox_sex.Text = "男性"
        '
        'GroupBox_dependents
        '
        Me.GroupBox_dependents.Controls.Add(Me.Label113)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox71)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox72)
        Me.GroupBox_dependents.Controls.Add(Me.Label116)
        Me.GroupBox_dependents.Controls.Add(Me.Label130)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox73)
        Me.GroupBox_dependents.Controls.Add(Me.Label131)
        Me.GroupBox_dependents.Controls.Add(Me.Label132)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox27)
        Me.GroupBox_dependents.Controls.Add(Me.Label133)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox28)
        Me.GroupBox_dependents.Controls.Add(Me.Label134)
        Me.GroupBox_dependents.Controls.Add(Me.Label138)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox74)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox29)
        Me.GroupBox_dependents.Controls.Add(Me.Label140)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox75)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox76)
        Me.GroupBox_dependents.Controls.Add(Me.Label142)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox30)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox77)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox80)
        Me.GroupBox_dependents.Controls.Add(Me.Label143)
        Me.GroupBox_dependents.Controls.Add(Me.Label144)
        Me.GroupBox_dependents.Controls.Add(Me.Label145)
        Me.GroupBox_dependents.Controls.Add(Me.Label146)
        Me.GroupBox_dependents.Controls.Add(Me.Label99)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox46)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox47)
        Me.GroupBox_dependents.Controls.Add(Me.Label100)
        Me.GroupBox_dependents.Controls.Add(Me.Label101)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox48)
        Me.GroupBox_dependents.Controls.Add(Me.Label102)
        Me.GroupBox_dependents.Controls.Add(Me.Label103)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox22)
        Me.GroupBox_dependents.Controls.Add(Me.Label104)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox24)
        Me.GroupBox_dependents.Controls.Add(Me.Label105)
        Me.GroupBox_dependents.Controls.Add(Me.Label106)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox49)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox25)
        Me.GroupBox_dependents.Controls.Add(Me.Label107)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox60)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox67)
        Me.GroupBox_dependents.Controls.Add(Me.Label108)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox26)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox68)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox69)
        Me.GroupBox_dependents.Controls.Add(Me.Label109)
        Me.GroupBox_dependents.Controls.Add(Me.Label110)
        Me.GroupBox_dependents.Controls.Add(Me.Label111)
        Me.GroupBox_dependents.Controls.Add(Me.Label112)
        Me.GroupBox_dependents.Controls.Add(Me.Label85)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox38)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox39)
        Me.GroupBox_dependents.Controls.Add(Me.Label86)
        Me.GroupBox_dependents.Controls.Add(Me.Label87)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox40)
        Me.GroupBox_dependents.Controls.Add(Me.Label88)
        Me.GroupBox_dependents.Controls.Add(Me.Label89)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox18)
        Me.GroupBox_dependents.Controls.Add(Me.Label90)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox19)
        Me.GroupBox_dependents.Controls.Add(Me.Label91)
        Me.GroupBox_dependents.Controls.Add(Me.Label92)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox41)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox20)
        Me.GroupBox_dependents.Controls.Add(Me.Label93)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox42)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox43)
        Me.GroupBox_dependents.Controls.Add(Me.Label94)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox21)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox44)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox45)
        Me.GroupBox_dependents.Controls.Add(Me.Label95)
        Me.GroupBox_dependents.Controls.Add(Me.Label96)
        Me.GroupBox_dependents.Controls.Add(Me.Label97)
        Me.GroupBox_dependents.Controls.Add(Me.Label98)
        Me.GroupBox_dependents.Controls.Add(Me.Label49)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox30)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox31)
        Me.GroupBox_dependents.Controls.Add(Me.Label50)
        Me.GroupBox_dependents.Controls.Add(Me.Label51)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox32)
        Me.GroupBox_dependents.Controls.Add(Me.Label52)
        Me.GroupBox_dependents.Controls.Add(Me.Label53)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox14)
        Me.GroupBox_dependents.Controls.Add(Me.Label58)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox15)
        Me.GroupBox_dependents.Controls.Add(Me.Label77)
        Me.GroupBox_dependents.Controls.Add(Me.Label78)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox33)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox16)
        Me.GroupBox_dependents.Controls.Add(Me.Label79)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox34)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox35)
        Me.GroupBox_dependents.Controls.Add(Me.Label80)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox17)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox36)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox37)
        Me.GroupBox_dependents.Controls.Add(Me.Label81)
        Me.GroupBox_dependents.Controls.Add(Me.Label82)
        Me.GroupBox_dependents.Controls.Add(Me.Label83)
        Me.GroupBox_dependents.Controls.Add(Me.Label84)
        Me.GroupBox_dependents.Controls.Add(Me.Label35)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox21)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox22)
        Me.GroupBox_dependents.Controls.Add(Me.Label36)
        Me.GroupBox_dependents.Controls.Add(Me.Label37)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox23)
        Me.GroupBox_dependents.Controls.Add(Me.Label38)
        Me.GroupBox_dependents.Controls.Add(Me.Label39)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox10)
        Me.GroupBox_dependents.Controls.Add(Me.Label40)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox11)
        Me.GroupBox_dependents.Controls.Add(Me.Label41)
        Me.GroupBox_dependents.Controls.Add(Me.Label42)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox24)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox12)
        Me.GroupBox_dependents.Controls.Add(Me.Label43)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox25)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox26)
        Me.GroupBox_dependents.Controls.Add(Me.Label44)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox13)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox28)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox29)
        Me.GroupBox_dependents.Controls.Add(Me.Label45)
        Me.GroupBox_dependents.Controls.Add(Me.Label46)
        Me.GroupBox_dependents.Controls.Add(Me.Label47)
        Me.GroupBox_dependents.Controls.Add(Me.Label48)
        Me.GroupBox_dependents.Controls.Add(Me.Label21)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox12)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox13)
        Me.GroupBox_dependents.Controls.Add(Me.Label22)
        Me.GroupBox_dependents.Controls.Add(Me.Label23)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox14)
        Me.GroupBox_dependents.Controls.Add(Me.Label24)
        Me.GroupBox_dependents.Controls.Add(Me.Label25)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox6)
        Me.GroupBox_dependents.Controls.Add(Me.Label26)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox7)
        Me.GroupBox_dependents.Controls.Add(Me.Label27)
        Me.GroupBox_dependents.Controls.Add(Me.Label28)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox15)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox8)
        Me.GroupBox_dependents.Controls.Add(Me.Label29)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox16)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox17)
        Me.GroupBox_dependents.Controls.Add(Me.Label30)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox9)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox18)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox19)
        Me.GroupBox_dependents.Controls.Add(Me.Label31)
        Me.GroupBox_dependents.Controls.Add(Me.Label32)
        Me.GroupBox_dependents.Controls.Add(Me.Label33)
        Me.GroupBox_dependents.Controls.Add(Me.Label34)
        Me.GroupBox_dependents.Controls.Add(Me.Label19)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox10)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox11)
        Me.GroupBox_dependents.Controls.Add(Me.Label20)
        Me.GroupBox_dependents.Controls.Add(Me.Label16)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox9)
        Me.GroupBox_dependents.Controls.Add(Me.Label17)
        Me.GroupBox_dependents.Controls.Add(Me.Label18)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox3)
        Me.GroupBox_dependents.Controls.Add(Me.Label9)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox4)
        Me.GroupBox_dependents.Controls.Add(Me.Label10)
        Me.GroupBox_dependents.Controls.Add(Me.Label11)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox7)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox5)
        Me.GroupBox_dependents.Controls.Add(Me.Label12)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox3)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox4)
        Me.GroupBox_dependents.Controls.Add(Me.Label3)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox2)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox5)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox6)
        Me.GroupBox_dependents.Controls.Add(Me.Label4)
        Me.GroupBox_dependents.Controls.Add(Me.Label5)
        Me.GroupBox_dependents.Controls.Add(Me.Label6)
        Me.GroupBox_dependents.Controls.Add(Me.Label8)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox27)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox20)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox52)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox85)
        Me.GroupBox_dependents.Location = New System.Drawing.Point(570, 228)
        Me.GroupBox_dependents.Name = "GroupBox_dependents"
        Me.GroupBox_dependents.Size = New System.Drawing.Size(739, 515)
        Me.GroupBox_dependents.TabIndex = 627
        Me.GroupBox_dependents.TabStop = False
        Me.GroupBox_dependents.Text = "扶養家族情報"
        '
        'Label113
        '
        Me.Label113.AccessibleName = "-"
        Me.Label113.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label113.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label113.Location = New System.Drawing.Point(530, 487)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(93, 21)
        Me.Label113.TabIndex = 803
        Me.Label113.Text = "マイナンバー"
        Me.Label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox71
        '
        Me.TextBox71.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox71.Location = New System.Drawing.Point(629, 487)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(94, 21)
        Me.TextBox71.TabIndex = 800
        Me.TextBox71.Text = "12345678901"
        '
        'TextBox72
        '
        Me.TextBox72.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox72.Location = New System.Drawing.Point(629, 464)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(50, 21)
        Me.TextBox72.TabIndex = 815
        Me.TextBox72.Text = "長男"
        '
        'Label116
        '
        Me.Label116.AccessibleName = "-"
        Me.Label116.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label116.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label116.Location = New System.Drawing.Point(530, 464)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(93, 21)
        Me.Label116.TabIndex = 814
        Me.Label116.Text = "続柄"
        Me.Label116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label130
        '
        Me.Label130.AccessibleName = "-"
        Me.Label130.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label130.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label130.Location = New System.Drawing.Point(468, 487)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(20, 21)
        Me.Label130.TabIndex = 813
        Me.Label130.Text = "歳"
        Me.Label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox73
        '
        Me.TextBox73.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox73.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox73.Location = New System.Drawing.Point(433, 487)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(32, 21)
        Me.TextBox73.TabIndex = 812
        Me.TextBox73.Text = "28"
        Me.TextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label131
        '
        Me.Label131.AccessibleName = "-"
        Me.Label131.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label131.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label131.Location = New System.Drawing.Point(334, 487)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(70, 21)
        Me.Label131.TabIndex = 811
        Me.Label131.Text = "年齢"
        Me.Label131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label132
        '
        Me.Label132.AccessibleName = "-"
        Me.Label132.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label132.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label132.Location = New System.Drawing.Point(410, 487)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(20, 21)
        Me.Label132.TabIndex = 810
        Me.Label132.Text = "満"
        Me.Label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox27
        '
        Me.ComboBox27.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Location = New System.Drawing.Point(194, 487)
        Me.ComboBox27.Name = "ComboBox27"
        Me.ComboBox27.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox27.TabIndex = 809
        Me.ComboBox27.Text = "12"
        '
        'Label133
        '
        Me.Label133.AccessibleName = "-"
        Me.Label133.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label133.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label133.Location = New System.Drawing.Point(301, 487)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(20, 21)
        Me.Label133.TabIndex = 808
        Me.Label133.Text = "日"
        Me.Label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox28
        '
        Me.ComboBox28.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox28.FormattingEnabled = True
        Me.ComboBox28.Location = New System.Drawing.Point(260, 487)
        Me.ComboBox28.Name = "ComboBox28"
        Me.ComboBox28.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox28.TabIndex = 807
        Me.ComboBox28.Text = "12"
        '
        'Label134
        '
        Me.Label134.AccessibleName = "-"
        Me.Label134.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label134.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label134.Location = New System.Drawing.Point(235, 487)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(20, 21)
        Me.Label134.TabIndex = 806
        Me.Label134.Text = "月"
        Me.Label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label138
        '
        Me.Label138.AccessibleName = "-"
        Me.Label138.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label138.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label138.Location = New System.Drawing.Point(170, 487)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(20, 21)
        Me.Label138.TabIndex = 805
        Me.Label138.Text = "年"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox74
        '
        Me.TextBox74.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox74.Location = New System.Drawing.Point(141, 487)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(25, 21)
        Me.TextBox74.TabIndex = 804
        Me.TextBox74.Text = "61"
        '
        'ComboBox29
        '
        Me.ComboBox29.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Location = New System.Drawing.Point(88, 487)
        Me.ComboBox29.Name = "ComboBox29"
        Me.ComboBox29.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox29.TabIndex = 802
        Me.ComboBox29.Text = "昭和"
        '
        'Label140
        '
        Me.Label140.AccessibleName = "-"
        Me.Label140.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label140.Location = New System.Drawing.Point(18, 487)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(64, 21)
        Me.Label140.TabIndex = 801
        Me.Label140.Text = "生年月日"
        Me.Label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox75
        '
        Me.TextBox75.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox75.Location = New System.Drawing.Point(113, 464)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(190, 21)
        Me.TextBox75.TabIndex = 799
        Me.TextBox75.Text = "古屋敷"
        '
        'TextBox76
        '
        Me.TextBox76.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox76.Location = New System.Drawing.Point(88, 441)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(215, 21)
        Me.TextBox76.TabIndex = 798
        Me.TextBox76.Text = "フルヤシキ"
        '
        'Label142
        '
        Me.Label142.AccessibleName = "-"
        Me.Label142.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label142.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label142.Location = New System.Drawing.Point(530, 441)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(93, 21)
        Me.Label142.TabIndex = 797
        Me.Label142.Text = "性別"
        Me.Label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox30
        '
        Me.ComboBox30.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox30.FormattingEnabled = True
        Me.ComboBox30.Location = New System.Drawing.Point(629, 441)
        Me.ComboBox30.Name = "ComboBox30"
        Me.ComboBox30.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox30.TabIndex = 796
        Me.ComboBox30.Text = "男性"
        '
        'TextBox77
        '
        Me.TextBox77.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox77.Location = New System.Drawing.Point(334, 464)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(190, 21)
        Me.TextBox77.TabIndex = 795
        Me.TextBox77.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox80
        '
        Me.TextBox80.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox80.Location = New System.Drawing.Point(309, 441)
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Size = New System.Drawing.Size(215, 21)
        Me.TextBox80.TabIndex = 794
        Me.TextBox80.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label143
        '
        Me.Label143.AccessibleName = "-"
        Me.Label143.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label143.Location = New System.Drawing.Point(88, 464)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(20, 21)
        Me.Label143.TabIndex = 790
        Me.Label143.Text = "姓"
        Me.Label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label144
        '
        Me.Label144.AccessibleName = "-"
        Me.Label144.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label144.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label144.Location = New System.Drawing.Point(18, 464)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(64, 21)
        Me.Label144.TabIndex = 792
        Me.Label144.Text = "氏名"
        Me.Label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label145
        '
        Me.Label145.AccessibleName = "-"
        Me.Label145.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label145.Location = New System.Drawing.Point(309, 464)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(20, 21)
        Me.Label145.TabIndex = 793
        Me.Label145.Text = "名"
        Me.Label145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label146
        '
        Me.Label146.AccessibleName = "-"
        Me.Label146.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label146.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label146.Location = New System.Drawing.Point(18, 441)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(64, 21)
        Me.Label146.TabIndex = 791
        Me.Label146.Text = "フリガナ"
        Me.Label146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label99
        '
        Me.Label99.AccessibleName = "-"
        Me.Label99.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label99.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label99.Location = New System.Drawing.Point(530, 416)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(93, 21)
        Me.Label99.TabIndex = 777
        Me.Label99.Text = "マイナンバー"
        Me.Label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox46
        '
        Me.TextBox46.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox46.Location = New System.Drawing.Point(629, 416)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(94, 21)
        Me.TextBox46.TabIndex = 774
        Me.TextBox46.Text = "12345678901"
        '
        'TextBox47
        '
        Me.TextBox47.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox47.Location = New System.Drawing.Point(629, 393)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(50, 21)
        Me.TextBox47.TabIndex = 789
        Me.TextBox47.Text = "長男"
        '
        'Label100
        '
        Me.Label100.AccessibleName = "-"
        Me.Label100.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label100.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label100.Location = New System.Drawing.Point(530, 393)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(93, 21)
        Me.Label100.TabIndex = 788
        Me.Label100.Text = "続柄"
        Me.Label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label101
        '
        Me.Label101.AccessibleName = "-"
        Me.Label101.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label101.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label101.Location = New System.Drawing.Point(468, 416)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(20, 21)
        Me.Label101.TabIndex = 787
        Me.Label101.Text = "歳"
        Me.Label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox48
        '
        Me.TextBox48.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox48.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox48.Location = New System.Drawing.Point(433, 416)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(32, 21)
        Me.TextBox48.TabIndex = 786
        Me.TextBox48.Text = "28"
        Me.TextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label102
        '
        Me.Label102.AccessibleName = "-"
        Me.Label102.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label102.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label102.Location = New System.Drawing.Point(334, 416)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(70, 21)
        Me.Label102.TabIndex = 785
        Me.Label102.Text = "年齢"
        Me.Label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label103
        '
        Me.Label103.AccessibleName = "-"
        Me.Label103.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label103.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label103.Location = New System.Drawing.Point(410, 416)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(20, 21)
        Me.Label103.TabIndex = 784
        Me.Label103.Text = "満"
        Me.Label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox22
        '
        Me.ComboBox22.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Location = New System.Drawing.Point(194, 416)
        Me.ComboBox22.Name = "ComboBox22"
        Me.ComboBox22.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox22.TabIndex = 783
        Me.ComboBox22.Text = "12"
        '
        'Label104
        '
        Me.Label104.AccessibleName = "-"
        Me.Label104.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label104.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label104.Location = New System.Drawing.Point(301, 416)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(20, 21)
        Me.Label104.TabIndex = 782
        Me.Label104.Text = "日"
        Me.Label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox24
        '
        Me.ComboBox24.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(260, 416)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox24.TabIndex = 781
        Me.ComboBox24.Text = "12"
        '
        'Label105
        '
        Me.Label105.AccessibleName = "-"
        Me.Label105.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label105.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label105.Location = New System.Drawing.Point(235, 416)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(20, 21)
        Me.Label105.TabIndex = 780
        Me.Label105.Text = "月"
        Me.Label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label106
        '
        Me.Label106.AccessibleName = "-"
        Me.Label106.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label106.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label106.Location = New System.Drawing.Point(170, 416)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(20, 21)
        Me.Label106.TabIndex = 779
        Me.Label106.Text = "年"
        Me.Label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox49
        '
        Me.TextBox49.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox49.Location = New System.Drawing.Point(141, 416)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(25, 21)
        Me.TextBox49.TabIndex = 778
        Me.TextBox49.Text = "61"
        '
        'ComboBox25
        '
        Me.ComboBox25.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Location = New System.Drawing.Point(88, 416)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox25.TabIndex = 776
        Me.ComboBox25.Text = "昭和"
        '
        'Label107
        '
        Me.Label107.AccessibleName = "-"
        Me.Label107.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label107.Location = New System.Drawing.Point(18, 416)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(64, 21)
        Me.Label107.TabIndex = 775
        Me.Label107.Text = "生年月日"
        Me.Label107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox60
        '
        Me.TextBox60.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox60.Location = New System.Drawing.Point(113, 393)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(190, 21)
        Me.TextBox60.TabIndex = 773
        Me.TextBox60.Text = "古屋敷"
        '
        'TextBox67
        '
        Me.TextBox67.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox67.Location = New System.Drawing.Point(88, 370)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(215, 21)
        Me.TextBox67.TabIndex = 772
        Me.TextBox67.Text = "フルヤシキ"
        '
        'Label108
        '
        Me.Label108.AccessibleName = "-"
        Me.Label108.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label108.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label108.Location = New System.Drawing.Point(530, 370)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(93, 21)
        Me.Label108.TabIndex = 771
        Me.Label108.Text = "性別"
        Me.Label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox26
        '
        Me.ComboBox26.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox26.FormattingEnabled = True
        Me.ComboBox26.Location = New System.Drawing.Point(629, 370)
        Me.ComboBox26.Name = "ComboBox26"
        Me.ComboBox26.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox26.TabIndex = 770
        Me.ComboBox26.Text = "男性"
        '
        'TextBox68
        '
        Me.TextBox68.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox68.Location = New System.Drawing.Point(334, 393)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(190, 21)
        Me.TextBox68.TabIndex = 769
        Me.TextBox68.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox69
        '
        Me.TextBox69.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox69.Location = New System.Drawing.Point(309, 370)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(215, 21)
        Me.TextBox69.TabIndex = 768
        Me.TextBox69.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label109
        '
        Me.Label109.AccessibleName = "-"
        Me.Label109.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label109.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label109.Location = New System.Drawing.Point(88, 393)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(20, 21)
        Me.Label109.TabIndex = 764
        Me.Label109.Text = "姓"
        Me.Label109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label110
        '
        Me.Label110.AccessibleName = "-"
        Me.Label110.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label110.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label110.Location = New System.Drawing.Point(18, 393)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(64, 21)
        Me.Label110.TabIndex = 766
        Me.Label110.Text = "氏名"
        Me.Label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label111
        '
        Me.Label111.AccessibleName = "-"
        Me.Label111.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label111.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label111.Location = New System.Drawing.Point(309, 393)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(20, 21)
        Me.Label111.TabIndex = 767
        Me.Label111.Text = "名"
        Me.Label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label112
        '
        Me.Label112.AccessibleName = "-"
        Me.Label112.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label112.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label112.Location = New System.Drawing.Point(18, 370)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(64, 21)
        Me.Label112.TabIndex = 765
        Me.Label112.Text = "フリガナ"
        Me.Label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label85
        '
        Me.Label85.AccessibleName = "-"
        Me.Label85.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label85.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label85.Location = New System.Drawing.Point(530, 345)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(93, 21)
        Me.Label85.TabIndex = 751
        Me.Label85.Text = "マイナンバー"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox38
        '
        Me.TextBox38.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox38.Location = New System.Drawing.Point(629, 345)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(94, 21)
        Me.TextBox38.TabIndex = 748
        Me.TextBox38.Text = "12345678901"
        '
        'TextBox39
        '
        Me.TextBox39.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox39.Location = New System.Drawing.Point(629, 322)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(50, 21)
        Me.TextBox39.TabIndex = 763
        Me.TextBox39.Text = "長男"
        '
        'Label86
        '
        Me.Label86.AccessibleName = "-"
        Me.Label86.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label86.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label86.Location = New System.Drawing.Point(530, 322)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(93, 21)
        Me.Label86.TabIndex = 762
        Me.Label86.Text = "続柄"
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label87
        '
        Me.Label87.AccessibleName = "-"
        Me.Label87.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label87.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label87.Location = New System.Drawing.Point(468, 345)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(20, 21)
        Me.Label87.TabIndex = 761
        Me.Label87.Text = "歳"
        Me.Label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox40
        '
        Me.TextBox40.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox40.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox40.Location = New System.Drawing.Point(433, 345)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(32, 21)
        Me.TextBox40.TabIndex = 760
        Me.TextBox40.Text = "28"
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label88
        '
        Me.Label88.AccessibleName = "-"
        Me.Label88.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label88.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label88.Location = New System.Drawing.Point(334, 345)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(70, 21)
        Me.Label88.TabIndex = 759
        Me.Label88.Text = "年齢"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label89
        '
        Me.Label89.AccessibleName = "-"
        Me.Label89.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label89.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label89.Location = New System.Drawing.Point(410, 345)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(20, 21)
        Me.Label89.TabIndex = 758
        Me.Label89.Text = "満"
        Me.Label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox18
        '
        Me.ComboBox18.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(194, 345)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox18.TabIndex = 757
        Me.ComboBox18.Text = "12"
        '
        'Label90
        '
        Me.Label90.AccessibleName = "-"
        Me.Label90.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label90.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label90.Location = New System.Drawing.Point(301, 345)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(20, 21)
        Me.Label90.TabIndex = 756
        Me.Label90.Text = "日"
        Me.Label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox19
        '
        Me.ComboBox19.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(260, 345)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox19.TabIndex = 755
        Me.ComboBox19.Text = "12"
        '
        'Label91
        '
        Me.Label91.AccessibleName = "-"
        Me.Label91.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label91.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label91.Location = New System.Drawing.Point(235, 345)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(20, 21)
        Me.Label91.TabIndex = 754
        Me.Label91.Text = "月"
        Me.Label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label92
        '
        Me.Label92.AccessibleName = "-"
        Me.Label92.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label92.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label92.Location = New System.Drawing.Point(170, 345)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(20, 21)
        Me.Label92.TabIndex = 753
        Me.Label92.Text = "年"
        Me.Label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox41
        '
        Me.TextBox41.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox41.Location = New System.Drawing.Point(141, 345)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(25, 21)
        Me.TextBox41.TabIndex = 752
        Me.TextBox41.Text = "61"
        '
        'ComboBox20
        '
        Me.ComboBox20.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(88, 345)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox20.TabIndex = 750
        Me.ComboBox20.Text = "昭和"
        '
        'Label93
        '
        Me.Label93.AccessibleName = "-"
        Me.Label93.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label93.Location = New System.Drawing.Point(18, 345)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(64, 21)
        Me.Label93.TabIndex = 749
        Me.Label93.Text = "生年月日"
        Me.Label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox42
        '
        Me.TextBox42.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox42.Location = New System.Drawing.Point(113, 322)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(190, 21)
        Me.TextBox42.TabIndex = 747
        Me.TextBox42.Text = "古屋敷"
        '
        'TextBox43
        '
        Me.TextBox43.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox43.Location = New System.Drawing.Point(88, 299)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(215, 21)
        Me.TextBox43.TabIndex = 746
        Me.TextBox43.Text = "フルヤシキ"
        '
        'Label94
        '
        Me.Label94.AccessibleName = "-"
        Me.Label94.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label94.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label94.Location = New System.Drawing.Point(530, 299)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(93, 21)
        Me.Label94.TabIndex = 745
        Me.Label94.Text = "性別"
        Me.Label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox21
        '
        Me.ComboBox21.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(629, 299)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox21.TabIndex = 744
        Me.ComboBox21.Text = "男性"
        '
        'TextBox44
        '
        Me.TextBox44.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox44.Location = New System.Drawing.Point(334, 322)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(190, 21)
        Me.TextBox44.TabIndex = 743
        Me.TextBox44.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox45
        '
        Me.TextBox45.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox45.Location = New System.Drawing.Point(309, 299)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(215, 21)
        Me.TextBox45.TabIndex = 742
        Me.TextBox45.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label95
        '
        Me.Label95.AccessibleName = "-"
        Me.Label95.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label95.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label95.Location = New System.Drawing.Point(88, 322)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(20, 21)
        Me.Label95.TabIndex = 738
        Me.Label95.Text = "姓"
        Me.Label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label96
        '
        Me.Label96.AccessibleName = "-"
        Me.Label96.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label96.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label96.Location = New System.Drawing.Point(18, 322)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(64, 21)
        Me.Label96.TabIndex = 740
        Me.Label96.Text = "氏名"
        Me.Label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label97
        '
        Me.Label97.AccessibleName = "-"
        Me.Label97.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label97.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label97.Location = New System.Drawing.Point(309, 322)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(20, 21)
        Me.Label97.TabIndex = 741
        Me.Label97.Text = "名"
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label98
        '
        Me.Label98.AccessibleName = "-"
        Me.Label98.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label98.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label98.Location = New System.Drawing.Point(18, 299)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(64, 21)
        Me.Label98.TabIndex = 739
        Me.Label98.Text = "フリガナ"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.AccessibleName = "-"
        Me.Label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label49.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label49.Location = New System.Drawing.Point(530, 274)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(93, 21)
        Me.Label49.TabIndex = 725
        Me.Label49.Text = "マイナンバー"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox30
        '
        Me.TextBox30.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox30.Location = New System.Drawing.Point(629, 274)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(94, 21)
        Me.TextBox30.TabIndex = 722
        Me.TextBox30.Text = "12345678901"
        '
        'TextBox31
        '
        Me.TextBox31.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox31.Location = New System.Drawing.Point(629, 251)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(50, 21)
        Me.TextBox31.TabIndex = 737
        Me.TextBox31.Text = "長男"
        '
        'Label50
        '
        Me.Label50.AccessibleName = "-"
        Me.Label50.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label50.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label50.Location = New System.Drawing.Point(530, 251)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(93, 21)
        Me.Label50.TabIndex = 736
        Me.Label50.Text = "続柄"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label51
        '
        Me.Label51.AccessibleName = "-"
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label51.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label51.Location = New System.Drawing.Point(468, 274)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(20, 21)
        Me.Label51.TabIndex = 735
        Me.Label51.Text = "歳"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox32
        '
        Me.TextBox32.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox32.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox32.Location = New System.Drawing.Point(433, 274)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(32, 21)
        Me.TextBox32.TabIndex = 734
        Me.TextBox32.Text = "28"
        Me.TextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label52
        '
        Me.Label52.AccessibleName = "-"
        Me.Label52.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label52.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label52.Location = New System.Drawing.Point(334, 274)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(70, 21)
        Me.Label52.TabIndex = 733
        Me.Label52.Text = "年齢"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label53
        '
        Me.Label53.AccessibleName = "-"
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label53.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label53.Location = New System.Drawing.Point(410, 274)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(20, 21)
        Me.Label53.TabIndex = 732
        Me.Label53.Text = "満"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox14
        '
        Me.ComboBox14.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(194, 274)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox14.TabIndex = 731
        Me.ComboBox14.Text = "12"
        '
        'Label58
        '
        Me.Label58.AccessibleName = "-"
        Me.Label58.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label58.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label58.Location = New System.Drawing.Point(301, 274)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(20, 21)
        Me.Label58.TabIndex = 730
        Me.Label58.Text = "日"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox15
        '
        Me.ComboBox15.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(260, 274)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox15.TabIndex = 729
        Me.ComboBox15.Text = "12"
        '
        'Label77
        '
        Me.Label77.AccessibleName = "-"
        Me.Label77.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label77.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label77.Location = New System.Drawing.Point(235, 274)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(20, 21)
        Me.Label77.TabIndex = 728
        Me.Label77.Text = "月"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label78
        '
        Me.Label78.AccessibleName = "-"
        Me.Label78.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label78.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label78.Location = New System.Drawing.Point(170, 274)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(20, 21)
        Me.Label78.TabIndex = 727
        Me.Label78.Text = "年"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox33
        '
        Me.TextBox33.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox33.Location = New System.Drawing.Point(141, 274)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(25, 21)
        Me.TextBox33.TabIndex = 726
        Me.TextBox33.Text = "61"
        '
        'ComboBox16
        '
        Me.ComboBox16.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(88, 274)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox16.TabIndex = 724
        Me.ComboBox16.Text = "昭和"
        '
        'Label79
        '
        Me.Label79.AccessibleName = "-"
        Me.Label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label79.Location = New System.Drawing.Point(18, 274)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(64, 21)
        Me.Label79.TabIndex = 723
        Me.Label79.Text = "生年月日"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox34
        '
        Me.TextBox34.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox34.Location = New System.Drawing.Point(113, 251)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(190, 21)
        Me.TextBox34.TabIndex = 721
        Me.TextBox34.Text = "古屋敷"
        '
        'TextBox35
        '
        Me.TextBox35.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox35.Location = New System.Drawing.Point(88, 228)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(215, 21)
        Me.TextBox35.TabIndex = 720
        Me.TextBox35.Text = "フルヤシキ"
        '
        'Label80
        '
        Me.Label80.AccessibleName = "-"
        Me.Label80.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label80.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label80.Location = New System.Drawing.Point(530, 228)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(93, 21)
        Me.Label80.TabIndex = 719
        Me.Label80.Text = "性別"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox17
        '
        Me.ComboBox17.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(629, 228)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox17.TabIndex = 718
        Me.ComboBox17.Text = "男性"
        '
        'TextBox36
        '
        Me.TextBox36.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox36.Location = New System.Drawing.Point(334, 251)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(190, 21)
        Me.TextBox36.TabIndex = 717
        Me.TextBox36.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox37
        '
        Me.TextBox37.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox37.Location = New System.Drawing.Point(309, 228)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(215, 21)
        Me.TextBox37.TabIndex = 716
        Me.TextBox37.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label81
        '
        Me.Label81.AccessibleName = "-"
        Me.Label81.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label81.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label81.Location = New System.Drawing.Point(88, 251)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(20, 21)
        Me.Label81.TabIndex = 712
        Me.Label81.Text = "姓"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label82
        '
        Me.Label82.AccessibleName = "-"
        Me.Label82.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label82.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label82.Location = New System.Drawing.Point(18, 251)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(64, 21)
        Me.Label82.TabIndex = 714
        Me.Label82.Text = "氏名"
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label83
        '
        Me.Label83.AccessibleName = "-"
        Me.Label83.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label83.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label83.Location = New System.Drawing.Point(309, 251)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(20, 21)
        Me.Label83.TabIndex = 715
        Me.Label83.Text = "名"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label84
        '
        Me.Label84.AccessibleName = "-"
        Me.Label84.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label84.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label84.Location = New System.Drawing.Point(18, 228)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(64, 21)
        Me.Label84.TabIndex = 713
        Me.Label84.Text = "フリガナ"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.AccessibleName = "-"
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label35.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label35.Location = New System.Drawing.Point(530, 203)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(93, 21)
        Me.Label35.TabIndex = 699
        Me.Label35.Text = "マイナンバー"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox21
        '
        Me.TextBox21.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox21.Location = New System.Drawing.Point(629, 203)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(94, 21)
        Me.TextBox21.TabIndex = 696
        Me.TextBox21.Text = "12345678901"
        '
        'TextBox22
        '
        Me.TextBox22.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox22.Location = New System.Drawing.Point(629, 180)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(50, 21)
        Me.TextBox22.TabIndex = 711
        Me.TextBox22.Text = "長男"
        '
        'Label36
        '
        Me.Label36.AccessibleName = "-"
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label36.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label36.Location = New System.Drawing.Point(530, 180)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(93, 21)
        Me.Label36.TabIndex = 710
        Me.Label36.Text = "続柄"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label37
        '
        Me.Label37.AccessibleName = "-"
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label37.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label37.Location = New System.Drawing.Point(468, 203)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(20, 21)
        Me.Label37.TabIndex = 709
        Me.Label37.Text = "歳"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox23
        '
        Me.TextBox23.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox23.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox23.Location = New System.Drawing.Point(433, 203)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(32, 21)
        Me.TextBox23.TabIndex = 708
        Me.TextBox23.Text = "28"
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label38
        '
        Me.Label38.AccessibleName = "-"
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label38.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label38.Location = New System.Drawing.Point(334, 203)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(70, 21)
        Me.Label38.TabIndex = 707
        Me.Label38.Text = "年齢"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.AccessibleName = "-"
        Me.Label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label39.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label39.Location = New System.Drawing.Point(410, 203)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(20, 21)
        Me.Label39.TabIndex = 706
        Me.Label39.Text = "満"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox10
        '
        Me.ComboBox10.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(194, 203)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox10.TabIndex = 705
        Me.ComboBox10.Text = "12"
        '
        'Label40
        '
        Me.Label40.AccessibleName = "-"
        Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label40.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label40.Location = New System.Drawing.Point(301, 203)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(20, 21)
        Me.Label40.TabIndex = 704
        Me.Label40.Text = "日"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox11
        '
        Me.ComboBox11.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(260, 203)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox11.TabIndex = 703
        Me.ComboBox11.Text = "12"
        '
        'Label41
        '
        Me.Label41.AccessibleName = "-"
        Me.Label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label41.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label41.Location = New System.Drawing.Point(235, 203)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(20, 21)
        Me.Label41.TabIndex = 702
        Me.Label41.Text = "月"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.AccessibleName = "-"
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label42.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label42.Location = New System.Drawing.Point(170, 203)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(20, 21)
        Me.Label42.TabIndex = 701
        Me.Label42.Text = "年"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox24
        '
        Me.TextBox24.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox24.Location = New System.Drawing.Point(141, 203)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(25, 21)
        Me.TextBox24.TabIndex = 700
        Me.TextBox24.Text = "61"
        '
        'ComboBox12
        '
        Me.ComboBox12.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(88, 203)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox12.TabIndex = 698
        Me.ComboBox12.Text = "昭和"
        '
        'Label43
        '
        Me.Label43.AccessibleName = "-"
        Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label43.Location = New System.Drawing.Point(18, 203)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(64, 21)
        Me.Label43.TabIndex = 697
        Me.Label43.Text = "生年月日"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox25
        '
        Me.TextBox25.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox25.Location = New System.Drawing.Point(113, 180)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(190, 21)
        Me.TextBox25.TabIndex = 695
        Me.TextBox25.Text = "古屋敷"
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox26.Location = New System.Drawing.Point(88, 157)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(215, 21)
        Me.TextBox26.TabIndex = 694
        Me.TextBox26.Text = "フルヤシキ"
        '
        'Label44
        '
        Me.Label44.AccessibleName = "-"
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label44.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label44.Location = New System.Drawing.Point(530, 157)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(93, 21)
        Me.Label44.TabIndex = 693
        Me.Label44.Text = "性別"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox13
        '
        Me.ComboBox13.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(629, 157)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox13.TabIndex = 692
        Me.ComboBox13.Text = "男性"
        '
        'TextBox28
        '
        Me.TextBox28.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox28.Location = New System.Drawing.Point(334, 180)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(190, 21)
        Me.TextBox28.TabIndex = 691
        Me.TextBox28.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox29
        '
        Me.TextBox29.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox29.Location = New System.Drawing.Point(309, 157)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(215, 21)
        Me.TextBox29.TabIndex = 690
        Me.TextBox29.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label45
        '
        Me.Label45.AccessibleName = "-"
        Me.Label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label45.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label45.Location = New System.Drawing.Point(88, 180)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(20, 21)
        Me.Label45.TabIndex = 686
        Me.Label45.Text = "姓"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label46
        '
        Me.Label46.AccessibleName = "-"
        Me.Label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label46.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label46.Location = New System.Drawing.Point(18, 180)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(64, 21)
        Me.Label46.TabIndex = 688
        Me.Label46.Text = "氏名"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.AccessibleName = "-"
        Me.Label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label47.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label47.Location = New System.Drawing.Point(309, 180)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(20, 21)
        Me.Label47.TabIndex = 689
        Me.Label47.Text = "名"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.AccessibleName = "-"
        Me.Label48.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label48.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label48.Location = New System.Drawing.Point(18, 157)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(64, 21)
        Me.Label48.TabIndex = 687
        Me.Label48.Text = "フリガナ"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AccessibleName = "-"
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label21.Location = New System.Drawing.Point(530, 132)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(93, 21)
        Me.Label21.TabIndex = 673
        Me.Label21.Text = "マイナンバー"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox12.Location = New System.Drawing.Point(629, 132)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(94, 21)
        Me.TextBox12.TabIndex = 670
        Me.TextBox12.Text = "12345678901"
        '
        'TextBox13
        '
        Me.TextBox13.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox13.Location = New System.Drawing.Point(629, 109)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(50, 21)
        Me.TextBox13.TabIndex = 685
        Me.TextBox13.Text = "長男"
        '
        'Label22
        '
        Me.Label22.AccessibleName = "-"
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label22.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label22.Location = New System.Drawing.Point(530, 109)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(93, 21)
        Me.Label22.TabIndex = 684
        Me.Label22.Text = "続柄"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AccessibleName = "-"
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label23.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label23.Location = New System.Drawing.Point(468, 132)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(20, 21)
        Me.Label23.TabIndex = 683
        Me.Label23.Text = "歳"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox14
        '
        Me.TextBox14.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox14.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox14.Location = New System.Drawing.Point(433, 132)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(32, 21)
        Me.TextBox14.TabIndex = 682
        Me.TextBox14.Text = "28"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.AccessibleName = "-"
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label24.Location = New System.Drawing.Point(334, 132)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(70, 21)
        Me.Label24.TabIndex = 681
        Me.Label24.Text = "年齢"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.AccessibleName = "-"
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label25.Location = New System.Drawing.Point(410, 132)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(20, 21)
        Me.Label25.TabIndex = 680
        Me.Label25.Text = "満"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox6
        '
        Me.ComboBox6.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(194, 132)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox6.TabIndex = 679
        Me.ComboBox6.Text = "12"
        '
        'Label26
        '
        Me.Label26.AccessibleName = "-"
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label26.Location = New System.Drawing.Point(301, 132)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(20, 21)
        Me.Label26.TabIndex = 678
        Me.Label26.Text = "日"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox7
        '
        Me.ComboBox7.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(260, 132)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox7.TabIndex = 677
        Me.ComboBox7.Text = "12"
        '
        'Label27
        '
        Me.Label27.AccessibleName = "-"
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label27.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label27.Location = New System.Drawing.Point(235, 132)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(20, 21)
        Me.Label27.TabIndex = 676
        Me.Label27.Text = "月"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AccessibleName = "-"
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label28.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label28.Location = New System.Drawing.Point(170, 132)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(20, 21)
        Me.Label28.TabIndex = 675
        Me.Label28.Text = "年"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox15
        '
        Me.TextBox15.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox15.Location = New System.Drawing.Point(141, 132)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(25, 21)
        Me.TextBox15.TabIndex = 674
        Me.TextBox15.Text = "61"
        '
        'ComboBox8
        '
        Me.ComboBox8.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(88, 132)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox8.TabIndex = 672
        Me.ComboBox8.Text = "昭和"
        '
        'Label29
        '
        Me.Label29.AccessibleName = "-"
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Location = New System.Drawing.Point(18, 132)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 21)
        Me.Label29.TabIndex = 671
        Me.Label29.Text = "生年月日"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox16
        '
        Me.TextBox16.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox16.Location = New System.Drawing.Point(113, 109)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(190, 21)
        Me.TextBox16.TabIndex = 669
        Me.TextBox16.Text = "古屋敷"
        '
        'TextBox17
        '
        Me.TextBox17.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox17.Location = New System.Drawing.Point(88, 86)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(215, 21)
        Me.TextBox17.TabIndex = 668
        Me.TextBox17.Text = "フルヤシキ"
        '
        'Label30
        '
        Me.Label30.AccessibleName = "-"
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label30.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label30.Location = New System.Drawing.Point(530, 86)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(93, 21)
        Me.Label30.TabIndex = 667
        Me.Label30.Text = "性別"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox9
        '
        Me.ComboBox9.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(629, 86)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox9.TabIndex = 666
        Me.ComboBox9.Text = "男性"
        '
        'TextBox18
        '
        Me.TextBox18.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox18.Location = New System.Drawing.Point(334, 109)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(190, 21)
        Me.TextBox18.TabIndex = 665
        Me.TextBox18.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox19
        '
        Me.TextBox19.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox19.Location = New System.Drawing.Point(309, 86)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(215, 21)
        Me.TextBox19.TabIndex = 664
        Me.TextBox19.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label31
        '
        Me.Label31.AccessibleName = "-"
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label31.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label31.Location = New System.Drawing.Point(88, 109)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(20, 21)
        Me.Label31.TabIndex = 660
        Me.Label31.Text = "姓"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.AccessibleName = "-"
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label32.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label32.Location = New System.Drawing.Point(18, 109)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(64, 21)
        Me.Label32.TabIndex = 662
        Me.Label32.Text = "氏名"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label33
        '
        Me.Label33.AccessibleName = "-"
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label33.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label33.Location = New System.Drawing.Point(309, 109)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(20, 21)
        Me.Label33.TabIndex = 663
        Me.Label33.Text = "名"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label34
        '
        Me.Label34.AccessibleName = "-"
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label34.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label34.Location = New System.Drawing.Point(18, 86)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(64, 21)
        Me.Label34.TabIndex = 661
        Me.Label34.Text = "フリガナ"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.AccessibleName = "-"
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label19.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label19.Location = New System.Drawing.Point(530, 61)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(93, 21)
        Me.Label19.TabIndex = 647
        Me.Label19.Text = "マイナンバー"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox10
        '
        Me.TextBox10.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox10.Location = New System.Drawing.Point(629, 61)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(94, 21)
        Me.TextBox10.TabIndex = 646
        Me.TextBox10.Text = "12345678901"
        '
        'TextBox11
        '
        Me.TextBox11.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox11.Location = New System.Drawing.Point(629, 38)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(50, 21)
        Me.TextBox11.TabIndex = 659
        Me.TextBox11.Text = "長男"
        '
        'Label20
        '
        Me.Label20.AccessibleName = "-"
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label20.Location = New System.Drawing.Point(530, 38)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(93, 21)
        Me.Label20.TabIndex = 658
        Me.Label20.Text = "続柄"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AccessibleName = "-"
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label16.Location = New System.Drawing.Point(468, 61)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 21)
        Me.Label16.TabIndex = 657
        Me.Label16.Text = "歳"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox9
        '
        Me.TextBox9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox9.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox9.Location = New System.Drawing.Point(433, 61)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(32, 21)
        Me.TextBox9.TabIndex = 656
        Me.TextBox9.Text = "28"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AccessibleName = "-"
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label17.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label17.Location = New System.Drawing.Point(334, 61)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(70, 21)
        Me.Label17.TabIndex = 655
        Me.Label17.Text = "年齢"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.AccessibleName = "-"
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label18.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label18.Location = New System.Drawing.Point(410, 61)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(20, 21)
        Me.Label18.TabIndex = 654
        Me.Label18.Text = "満"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox3
        '
        Me.ComboBox3.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(194, 61)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox3.TabIndex = 653
        Me.ComboBox3.Text = "12"
        '
        'Label9
        '
        Me.Label9.AccessibleName = "-"
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label9.Location = New System.Drawing.Point(301, 61)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(20, 21)
        Me.Label9.TabIndex = 652
        Me.Label9.Text = "日"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox4
        '
        Me.ComboBox4.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(260, 61)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(38, 21)
        Me.ComboBox4.TabIndex = 651
        Me.ComboBox4.Text = "12"
        '
        'Label10
        '
        Me.Label10.AccessibleName = "-"
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label10.Location = New System.Drawing.Point(235, 61)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(20, 21)
        Me.Label10.TabIndex = 650
        Me.Label10.Text = "月"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AccessibleName = "-"
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label11.Location = New System.Drawing.Point(170, 61)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(20, 21)
        Me.Label11.TabIndex = 649
        Me.Label11.Text = "年"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox7.Location = New System.Drawing.Point(141, 61)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(25, 21)
        Me.TextBox7.TabIndex = 648
        Me.TextBox7.Text = "61"
        '
        'ComboBox5
        '
        Me.ComboBox5.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(88, 61)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox5.TabIndex = 647
        Me.ComboBox5.Text = "昭和"
        '
        'Label12
        '
        Me.Label12.AccessibleName = "-"
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label12.Location = New System.Drawing.Point(18, 61)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 21)
        Me.Label12.TabIndex = 646
        Me.Label12.Text = "生年月日"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox3.Location = New System.Drawing.Point(113, 38)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(190, 21)
        Me.TextBox3.TabIndex = 642
        Me.TextBox3.Text = "古屋敷"
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox4.Location = New System.Drawing.Point(88, 15)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(215, 21)
        Me.TextBox4.TabIndex = 641
        Me.TextBox4.Text = "フルヤシキ"
        '
        'Label3
        '
        Me.Label3.AccessibleName = "-"
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(530, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 21)
        Me.Label3.TabIndex = 640
        Me.Label3.Text = "性別"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox2
        '
        Me.ComboBox2.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(629, 15)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(50, 21)
        Me.ComboBox2.TabIndex = 639
        Me.ComboBox2.Text = "男性"
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox5.Location = New System.Drawing.Point(334, 38)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(190, 21)
        Me.TextBox5.TabIndex = 638
        Me.TextBox5.Text = "後部屋新九郎左衛門介之亟"
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox6.Location = New System.Drawing.Point(309, 15)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(215, 21)
        Me.TextBox6.TabIndex = 637
        Me.TextBox6.Text = "コウブヤシンキロウザエモンノスケノキョク"
        '
        'Label4
        '
        Me.Label4.AccessibleName = "-"
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label4.Location = New System.Drawing.Point(88, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 21)
        Me.Label4.TabIndex = 633
        Me.Label4.Text = "姓"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AccessibleName = "-"
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label5.Location = New System.Drawing.Point(18, 38)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 21)
        Me.Label5.TabIndex = 635
        Me.Label5.Text = "氏名"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AccessibleName = "-"
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label6.Location = New System.Drawing.Point(309, 38)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(20, 21)
        Me.Label6.TabIndex = 636
        Me.Label6.Text = "名"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AccessibleName = "-"
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Label8.Location = New System.Drawing.Point(18, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 21)
        Me.Label8.TabIndex = 634
        Me.Label8.Text = "フリガナ"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(-93, -67)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(110, 19)
        Me.TextBox27.TabIndex = 174
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(-93, -114)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(110, 19)
        Me.TextBox20.TabIndex = 156
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(-91, -161)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(110, 19)
        Me.TextBox52.TabIndex = 138
        '
        'TextBox85
        '
        Me.TextBox85.Location = New System.Drawing.Point(-93, -208)
        Me.TextBox85.Name = "TextBox85"
        Me.TextBox85.Size = New System.Drawing.Size(110, 19)
        Me.TextBox85.TabIndex = 120
        '
        'TextBox54
        '
        Me.TextBox54.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox54.Location = New System.Drawing.Point(115, 109)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(215, 21)
        Me.TextBox54.TabIndex = 631
        Me.TextBox54.Text = "フルヤシキ"
        '
        'TextBox53
        '
        Me.TextBox53.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox53.Location = New System.Drawing.Point(140, 133)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(190, 21)
        Me.TextBox53.TabIndex = 632
        Me.TextBox53.Text = "古屋敷"
        '
        'TextBox56
        '
        Me.TextBox56.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox56.Location = New System.Drawing.Point(115, 285)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(50, 21)
        Me.TextBox56.TabIndex = 633
        Me.TextBox56.Text = "090"
        '
        'TextBox57
        '
        Me.TextBox57.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.TextBox57.Location = New System.Drawing.Point(276, 285)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(50, 21)
        Me.TextBox57.TabIndex = 634
        Me.TextBox57.Text = "1234"
        '
        'ComboBox23
        '
        Me.ComboBox23.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Location = New System.Drawing.Point(325, 189)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(45, 21)
        Me.ComboBox23.TabIndex = 635
        Me.ComboBox23.Text = "12"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(931, 76)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(125, 19)
        Me.DateTimePicker2.TabIndex = 729
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(798, 76)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(125, 19)
        Me.DateTimePicker1.TabIndex = 728
        '
        'TextBox_branchname
        '
        Me.TextBox_branchname.Location = New System.Drawing.Point(422, 41)
        Me.TextBox_branchname.Name = "TextBox_branchname"
        Me.TextBox_branchname.Size = New System.Drawing.Size(70, 21)
        Me.TextBox_branchname.TabIndex = 171
        Me.TextBox_branchname.Text = "651"
        '
        'TextBox_bankname
        '
        Me.TextBox_bankname.Location = New System.Drawing.Point(422, 18)
        Me.TextBox_bankname.Name = "TextBox_bankname"
        Me.TextBox_bankname.Size = New System.Drawing.Size(70, 21)
        Me.TextBox_bankname.TabIndex = 169
        Me.TextBox_bankname.Text = "0190"
        '
        'Label_bankname
        '
        Me.Label_bankname.AccessibleName = "-"
        Me.Label_bankname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_bankname.Location = New System.Drawing.Point(321, 18)
        Me.Label_bankname.Name = "Label_bankname"
        Me.Label_bankname.Size = New System.Drawing.Size(95, 21)
        Me.Label_bankname.TabIndex = 168
        Me.Label_bankname.Text = "銀行番号"
        Me.Label_bankname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_accounttype
        '
        Me.Label_accounttype.AccessibleName = "-"
        Me.Label_accounttype.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_accounttype.Location = New System.Drawing.Point(19, 65)
        Me.Label_accounttype.Name = "Label_accounttype"
        Me.Label_accounttype.Size = New System.Drawing.Size(70, 21)
        Me.Label_accounttype.TabIndex = 173
        Me.Label_accounttype.Text = "口座種別"
        Me.Label_accounttype.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(95, 65)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(70, 21)
        Me.ComboBox1.TabIndex = 172
        Me.ComboBox1.Text = "普通"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(250, 65)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(105, 21)
        Me.TextBox2.TabIndex = 175
        Me.TextBox2.Text = "0123456"
        '
        'Label1
        '
        Me.Label1.AccessibleName = "-"
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(321, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 21)
        Me.Label1.TabIndex = 176
        Me.Label1.Text = "支店番号"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AccessibleName = "-"
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(175, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 21)
        Me.Label2.TabIndex = 177
        Me.Label2.Text = "口座番号"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(95, 18)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(211, 21)
        Me.TextBox58.TabIndex = 179
        Me.TextBox58.Text = "三菱ＵＦＪ信託銀行"
        '
        'Label136
        '
        Me.Label136.AccessibleName = "-"
        Me.Label136.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label136.Location = New System.Drawing.Point(19, 18)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(70, 21)
        Me.Label136.TabIndex = 178
        Me.Label136.Text = "銀行名"
        Me.Label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox78
        '
        Me.TextBox78.Location = New System.Drawing.Point(95, 41)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(211, 21)
        Me.TextBox78.TabIndex = 181
        Me.TextBox78.Text = "和歌山支店"
        '
        'Label137
        '
        Me.Label137.AccessibleName = "-"
        Me.Label137.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label137.Location = New System.Drawing.Point(19, 41)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(70, 21)
        Me.Label137.TabIndex = 180
        Me.Label137.Text = "支店名"
        Me.Label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_bankinfo
        '
        Me.GroupBox_bankinfo.Controls.Add(Me.Label137)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox78)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label136)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox58)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label2)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label1)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox2)
        Me.GroupBox_bankinfo.Controls.Add(Me.ComboBox1)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label_accounttype)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label_bankname)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox_bankname)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox_branchname)
        Me.GroupBox_bankinfo.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.GroupBox_bankinfo.Location = New System.Drawing.Point(19, 494)
        Me.GroupBox_bankinfo.Name = "GroupBox_bankinfo"
        Me.GroupBox_bankinfo.Size = New System.Drawing.Size(515, 95)
        Me.GroupBox_bankinfo.TabIndex = 365
        Me.GroupBox_bankinfo.TabStop = False
        Me.GroupBox_bankinfo.Text = "銀行口座情報"
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button4.Location = New System.Drawing.Point(310, 17)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(80, 23)
        Me.Button4.TabIndex = 738
        Me.Button4.Text = "複製"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button5.Location = New System.Drawing.Point(396, 17)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(80, 23)
        Me.Button5.TabIndex = 737
        Me.Button5.Text = "クリア"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button2.Location = New System.Drawing.Point(677, 17)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 23)
        Me.Button2.TabIndex = 735
        Me.Button2.Text = "次へ→"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button_delete
        '
        Me.Button_delete.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_delete.Location = New System.Drawing.Point(777, 17)
        Me.Button_delete.Name = "Button_delete"
        Me.Button_delete.Size = New System.Drawing.Size(60, 23)
        Me.Button_delete.TabIndex = 733
        Me.Button_delete.Text = "削除"
        Me.Button_delete.UseVisualStyleBackColor = True
        '
        'Button_update
        '
        Me.Button_update.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_update.Location = New System.Drawing.Point(140, 17)
        Me.Button_update.Name = "Button_update"
        Me.Button_update.Size = New System.Drawing.Size(80, 23)
        Me.Button_update.TabIndex = 732
        Me.Button_update.Text = "編集"
        Me.Button_update.UseVisualStyleBackColor = True
        '
        'Button_insert
        '
        Me.Button_insert.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_insert.Location = New System.Drawing.Point(225, 17)
        Me.Button_insert.Name = "Button_insert"
        Me.Button_insert.Size = New System.Drawing.Size(80, 23)
        Me.Button_insert.TabIndex = 731
        Me.Button_insert.Text = "登録"
        Me.Button_insert.UseVisualStyleBackColor = True
        '
        'Button_select
        '
        Me.Button_select.AccessibleRole = System.Windows.Forms.AccessibleRole.Caret
        Me.Button_select.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button_select.Location = New System.Drawing.Point(17, 17)
        Me.Button_select.Name = "Button_select"
        Me.Button_select.Size = New System.Drawing.Size(116, 23)
        Me.Button_select.TabIndex = 730
        Me.Button_select.Text = "社員リスト参照"
        Me.Button_select.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button1.Location = New System.Drawing.Point(589, 17)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 23)
        Me.Button1.TabIndex = 734
        Me.Button1.Text = "←前へ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("MS UI Gothic", 10.0!)
        Me.Button3.Location = New System.Drawing.Point(482, 17)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(80, 23)
        Me.Button3.TabIndex = 736
        Me.Button3.Text = "印刷"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form_staff
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1333, 1002)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button_delete)
        Me.Controls.Add(Me.Button_update)
        Me.Controls.Add(Me.Button_insert)
        Me.Controls.Add(Me.Button_select)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.ComboBox23)
        Me.Controls.Add(Me.TextBox57)
        Me.Controls.Add(Me.TextBox56)
        Me.Controls.Add(Me.TextBox53)
        Me.Controls.Add(Me.TextBox54)
        Me.Controls.Add(Me.GroupBox_dependents)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.ComboBox_sex)
        Me.Controls.Add(Me.TextBox88)
        Me.Controls.Add(Me.TextBox89)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label141)
        Me.Controls.Add(Me.GroupBox_bankinfo)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.ComboBox39)
        Me.Controls.Add(Me.Label114)
        Me.Controls.Add(Me.ComboBox38)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label115)
        Me.Controls.Add(Me.ComboBox33)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox50)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox63)
        Me.Controls.Add(Me.TextBox64)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.TextBox62)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.TextBox61)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label_dependents)
        Me.Controls.Add(Me.ComboBox_dependents)
        Me.Controls.Add(Me.Button_pictselect)
        Me.Controls.Add(Me.Label_retire)
        Me.Controls.Add(Me.Label_belong)
        Me.Controls.Add(Me.TextBox_belong)
        Me.Controls.Add(Me.Label_joindate)
        Me.Controls.Add(Me.Label_company)
        Me.Controls.Add(Me.TextBox_Company)
        Me.Controls.Add(Me.PictureBox)
        Me.Controls.Add(Me.Label_nowdate)
        Me.Controls.Add(Me.TextBox_empnum)
        Me.Controls.Add(Me.TextBox_address1kana)
        Me.Controls.Add(Me.ComboBox_Pref)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button_pictupload)
        Me.Controls.Add(Me.Label_empnum)
        Me.Controls.Add(Me.TextBox_birthyear)
        Me.Controls.Add(Me.ComboBox_nengou)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "Form_staff"
        Me.Text = "社員データ"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox_dependents.ResumeLayout(False)
        Me.GroupBox_dependents.PerformLayout()
        Me.GroupBox_bankinfo.ResumeLayout(False)
        Me.GroupBox_bankinfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox39 As System.Windows.Forms.ComboBox
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents ComboBox38 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox34 As System.Windows.Forms.ComboBox
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents ComboBox33 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label_dependents As System.Windows.Forms.Label
    Friend WithEvents ComboBox_dependents As System.Windows.Forms.ComboBox
    Friend WithEvents Button_pictselect As System.Windows.Forms.Button
    Friend WithEvents Label_retire As System.Windows.Forms.Label
    Friend WithEvents Label_belong As System.Windows.Forms.Label
    Friend WithEvents TextBox_belong As System.Windows.Forms.TextBox
    Friend WithEvents Label_joindate As System.Windows.Forms.Label
    Friend WithEvents Label_company As System.Windows.Forms.Label
    Friend WithEvents TextBox_Company As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Label_nowdate As System.Windows.Forms.Label
    Friend WithEvents TextBox_empnum As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_address1kana As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox_Pref As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button_pictupload As System.Windows.Forms.Button
    Friend WithEvents Label_empnum As System.Windows.Forms.Label
    Friend WithEvents TextBox_birthyear As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox_nengou As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox88 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox89 As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_sex As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_dependents As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox85 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox79 As System.Windows.Forms.TextBox
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents TextBox86 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox87 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox90 As System.Windows.Forms.TextBox
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents ComboBox36 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox31 As System.Windows.Forms.ComboBox
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents ComboBox32 As System.Windows.Forms.ComboBox
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox35 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox23 As System.Windows.Forms.ComboBox
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents ComboBox27 As System.Windows.Forms.ComboBox
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents ComboBox28 As System.Windows.Forms.ComboBox
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox29 As System.Windows.Forms.ComboBox
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents ComboBox30 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox80 As System.Windows.Forms.TextBox
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents ComboBox22 As System.Windows.Forms.ComboBox
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents ComboBox24 As System.Windows.Forms.ComboBox
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox25 As System.Windows.Forms.ComboBox
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents ComboBox26 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents ComboBox18 As System.Windows.Forms.ComboBox
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents ComboBox19 As System.Windows.Forms.ComboBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox20 As System.Windows.Forms.ComboBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents ComboBox21 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents ComboBox15 As System.Windows.Forms.ComboBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox16 As System.Windows.Forms.ComboBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents ComboBox17 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox_branchname As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_bankname As System.Windows.Forms.TextBox
    Friend WithEvents Label_bankname As System.Windows.Forms.Label
    Friend WithEvents Label_accounttype As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents TextBox78 As System.Windows.Forms.TextBox
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_bankinfo As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button_delete As System.Windows.Forms.Button
    Friend WithEvents Button_update As System.Windows.Forms.Button
    Friend WithEvents Button_insert As System.Windows.Forms.Button
    Friend WithEvents Button_select As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
