﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_companion
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_companion))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label_dependents = New System.Windows.Forms.Label()
        Me.ComboBox_dependents = New System.Windows.Forms.ComboBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label_accounttype = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox_branchname = New System.Windows.Forms.TextBox()
        Me.TextBox_bankname = New System.Windows.Forms.TextBox()
        Me.Label_bankname = New System.Windows.Forms.Label()
        Me.GroupBox_bankinfo = New System.Windows.Forms.GroupBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.TextBox78 = New System.Windows.Forms.TextBox()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox_dependents = New System.Windows.Forms.GroupBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox74 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.ComboBox26 = New System.Windows.Forms.ComboBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.ComboBox27 = New System.Windows.Forms.ComboBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.ComboBox28 = New System.Windows.Forms.ComboBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.ComboBox29 = New System.Windows.Forms.ComboBox()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.ComboBox30 = New System.Windows.Forms.ComboBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.ComboBox31 = New System.Windows.Forms.ComboBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.ComboBox32 = New System.Windows.Forms.ComboBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button_pictselect = New System.Windows.Forms.Button()
        Me.Label_retire = New System.Windows.Forms.Label()
        Me.Label_belong = New System.Windows.Forms.Label()
        Me.TextBox_belong = New System.Windows.Forms.TextBox()
        Me.Label_joindate = New System.Windows.Forms.Label()
        Me.TextBox_joindate = New System.Windows.Forms.TextBox()
        Me.TextBox_retire = New System.Windows.Forms.TextBox()
        Me.Label_company = New System.Windows.Forms.Label()
        Me.TextBox_Company = New System.Windows.Forms.TextBox()
        Me.PictureBox = New System.Windows.Forms.PictureBox()
        Me.Button_delete = New System.Windows.Forms.Button()
        Me.Button_update = New System.Windows.Forms.Button()
        Me.Button_insert = New System.Windows.Forms.Button()
        Me.Button_select = New System.Windows.Forms.Button()
        Me.TextBox_address1kana = New System.Windows.Forms.TextBox()
        Me.ComboBox_Pref = New System.Windows.Forms.ComboBox()
        Me.ComboBox_sex = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button_pictupload = New System.Windows.Forms.Button()
        Me.TextBox_lastnamekana = New System.Windows.Forms.TextBox()
        Me.Label_lastname = New System.Windows.Forms.Label()
        Me.Label_lastupdate = New System.Windows.Forms.Label()
        Me.Label_nowdate = New System.Windows.Forms.Label()
        Me.TextBox_empnum = New System.Windows.Forms.TextBox()
        Me.Label_empnum = New System.Windows.Forms.Label()
        Me.TextBox_birthyear = New System.Windows.Forms.TextBox()
        Me.ComboBox_nengou = New System.Windows.Forms.ComboBox()
        Me.TextBox_telnumber1 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.ComboBox33 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBox79 = New System.Windows.Forms.TextBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.ComboBox34 = New System.Windows.Forms.ComboBox()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.ComboBox37 = New System.Windows.Forms.ComboBox()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.ComboBox35 = New System.Windows.Forms.ComboBox()
        Me.ComboBox36 = New System.Windows.Forms.ComboBox()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.ComboBox38 = New System.Windows.Forms.ComboBox()
        Me.ComboBox39 = New System.Windows.Forms.ComboBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox_bankinfo.SuspendLayout()
        Me.GroupBox_dependents.SuspendLayout()
        CType(Me.PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.k_grid02_15
        Me.GroupBox1.Controls.Add(Me.RichTextBox2)
        Me.GroupBox1.Location = New System.Drawing.Point(19, 912)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1178, 138)
        Me.GroupBox1.TabIndex = 202
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "更新履歴"
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.Location = New System.Drawing.Point(6, 14)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(1166, 118)
        Me.RichTextBox2.TabIndex = 106
        Me.RichTextBox2.Text = ""
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(17, 774)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(1180, 132)
        Me.RichTextBox1.TabIndex = 200
        Me.RichTextBox1.Text = ""
        '
        'Label54
        '
        Me.Label54.AccessibleName = "-"
        Me.Label54.Location = New System.Drawing.Point(18, 753)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(40, 18)
        Me.Label54.TabIndex = 199
        Me.Label54.Text = "備考"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_dependents
        '
        Me.Label_dependents.AccessibleName = "-"
        Me.Label_dependents.Location = New System.Drawing.Point(550, 207)
        Me.Label_dependents.Name = "Label_dependents"
        Me.Label_dependents.Size = New System.Drawing.Size(61, 18)
        Me.Label_dependents.TabIndex = 198
        Me.Label_dependents.Text = "扶養家族"
        Me.Label_dependents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_dependents
        '
        Me.ComboBox_dependents.FormattingEnabled = True
        Me.ComboBox_dependents.Location = New System.Drawing.Point(618, 206)
        Me.ComboBox_dependents.Name = "ComboBox_dependents"
        Me.ComboBox_dependents.Size = New System.Drawing.Size(47, 20)
        Me.ComboBox_dependents.TabIndex = 176
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(234, 64)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(241, 19)
        Me.TextBox2.TabIndex = 175
        '
        'Label_accounttype
        '
        Me.Label_accounttype.AccessibleName = "-"
        Me.Label_accounttype.Location = New System.Drawing.Point(19, 64)
        Me.Label_accounttype.Name = "Label_accounttype"
        Me.Label_accounttype.Size = New System.Drawing.Size(56, 18)
        Me.Label_accounttype.TabIndex = 173
        Me.Label_accounttype.Text = "口座種別"
        Me.Label_accounttype.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(82, 63)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(70, 20)
        Me.ComboBox1.TabIndex = 172
        '
        'TextBox_branchname
        '
        Me.TextBox_branchname.Location = New System.Drawing.Point(405, 39)
        Me.TextBox_branchname.Name = "TextBox_branchname"
        Me.TextBox_branchname.Size = New System.Drawing.Size(69, 19)
        Me.TextBox_branchname.TabIndex = 171
        '
        'TextBox_bankname
        '
        Me.TextBox_bankname.Location = New System.Drawing.Point(405, 18)
        Me.TextBox_bankname.Name = "TextBox_bankname"
        Me.TextBox_bankname.Size = New System.Drawing.Size(69, 19)
        Me.TextBox_bankname.TabIndex = 169
        '
        'Label_bankname
        '
        Me.Label_bankname.AccessibleName = "-"
        Me.Label_bankname.Location = New System.Drawing.Point(342, 18)
        Me.Label_bankname.Name = "Label_bankname"
        Me.Label_bankname.Size = New System.Drawing.Size(56, 18)
        Me.Label_bankname.TabIndex = 168
        Me.Label_bankname.Text = "銀行番号"
        Me.Label_bankname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_bankinfo
        '
        Me.GroupBox_bankinfo.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.k_grid02_14
        Me.GroupBox_bankinfo.Controls.Add(Me.Label137)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox78)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label136)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox58)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label2)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label1)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox2)
        Me.GroupBox_bankinfo.Controls.Add(Me.ComboBox1)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label_accounttype)
        Me.GroupBox_bankinfo.Controls.Add(Me.Label_bankname)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox_bankname)
        Me.GroupBox_bankinfo.Controls.Add(Me.TextBox_branchname)
        Me.GroupBox_bankinfo.Location = New System.Drawing.Point(19, 494)
        Me.GroupBox_bankinfo.Name = "GroupBox_bankinfo"
        Me.GroupBox_bankinfo.Size = New System.Drawing.Size(493, 95)
        Me.GroupBox_bankinfo.TabIndex = 201
        Me.GroupBox_bankinfo.TabStop = False
        Me.GroupBox_bankinfo.Text = "銀行口座情報"
        '
        'Label137
        '
        Me.Label137.AccessibleName = "-"
        Me.Label137.Location = New System.Drawing.Point(19, 41)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(56, 18)
        Me.Label137.TabIndex = 180
        Me.Label137.Text = "支店名"
        Me.Label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox78
        '
        Me.TextBox78.Location = New System.Drawing.Point(82, 41)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(241, 19)
        Me.TextBox78.TabIndex = 181
        '
        'Label136
        '
        Me.Label136.AccessibleName = "-"
        Me.Label136.Location = New System.Drawing.Point(19, 18)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(56, 18)
        Me.Label136.TabIndex = 178
        Me.Label136.Text = "銀行名"
        Me.Label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(82, 18)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(241, 19)
        Me.TextBox58.TabIndex = 179
        '
        'Label2
        '
        Me.Label2.AccessibleName = "-"
        Me.Label2.Location = New System.Drawing.Point(171, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 18)
        Me.Label2.TabIndex = 177
        Me.Label2.Text = "口座番号"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AccessibleName = "-"
        Me.Label1.Location = New System.Drawing.Point(342, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 18)
        Me.Label1.TabIndex = 176
        Me.Label1.Text = "支店番号"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_dependents
        '
        Me.GroupBox_dependents.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.k_grid02_36
        Me.GroupBox_dependents.Controls.Add(Me.TextBox49)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox42)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox35)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox28)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox19)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox11)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox74)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox45)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox38)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox31)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox23)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox15)
        Me.GroupBox_dependents.Controls.Add(Me.Label81)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox36)
        Me.GroupBox_dependents.Controls.Add(Me.Label82)
        Me.GroupBox_dependents.Controls.Add(Me.Label83)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox19)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox37)
        Me.GroupBox_dependents.Controls.Add(Me.Label84)
        Me.GroupBox_dependents.Controls.Add(Me.Label85)
        Me.GroupBox_dependents.Controls.Add(Me.Label86)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox20)
        Me.GroupBox_dependents.Controls.Add(Me.Label87)
        Me.GroupBox_dependents.Controls.Add(Me.Label88)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox39)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox40)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox21)
        Me.GroupBox_dependents.Controls.Add(Me.Label89)
        Me.GroupBox_dependents.Controls.Add(Me.Label90)
        Me.GroupBox_dependents.Controls.Add(Me.Label91)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox24)
        Me.GroupBox_dependents.Controls.Add(Me.Label92)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox41)
        Me.GroupBox_dependents.Controls.Add(Me.Label93)
        Me.GroupBox_dependents.Controls.Add(Me.Label94)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox43)
        Me.GroupBox_dependents.Controls.Add(Me.Label95)
        Me.GroupBox_dependents.Controls.Add(Me.Label96)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox25)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox44)
        Me.GroupBox_dependents.Controls.Add(Me.Label97)
        Me.GroupBox_dependents.Controls.Add(Me.Label98)
        Me.GroupBox_dependents.Controls.Add(Me.Label99)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox26)
        Me.GroupBox_dependents.Controls.Add(Me.Label100)
        Me.GroupBox_dependents.Controls.Add(Me.Label101)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox46)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox47)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox27)
        Me.GroupBox_dependents.Controls.Add(Me.Label102)
        Me.GroupBox_dependents.Controls.Add(Me.Label103)
        Me.GroupBox_dependents.Controls.Add(Me.Label104)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox28)
        Me.GroupBox_dependents.Controls.Add(Me.Label105)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox48)
        Me.GroupBox_dependents.Controls.Add(Me.Label106)
        Me.GroupBox_dependents.Controls.Add(Me.Label107)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox72)
        Me.GroupBox_dependents.Controls.Add(Me.Label108)
        Me.GroupBox_dependents.Controls.Add(Me.Label109)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox29)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox73)
        Me.GroupBox_dependents.Controls.Add(Me.Label110)
        Me.GroupBox_dependents.Controls.Add(Me.Label111)
        Me.GroupBox_dependents.Controls.Add(Me.Label112)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox30)
        Me.GroupBox_dependents.Controls.Add(Me.Label113)
        Me.GroupBox_dependents.Controls.Add(Me.Label130)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox75)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox76)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox31)
        Me.GroupBox_dependents.Controls.Add(Me.Label131)
        Me.GroupBox_dependents.Controls.Add(Me.Label132)
        Me.GroupBox_dependents.Controls.Add(Me.Label133)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox32)
        Me.GroupBox_dependents.Controls.Add(Me.Label134)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox77)
        Me.GroupBox_dependents.Controls.Add(Me.Label135)
        Me.GroupBox_dependents.Controls.Add(Me.Label45)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox29)
        Me.GroupBox_dependents.Controls.Add(Me.Label46)
        Me.GroupBox_dependents.Controls.Add(Me.Label47)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox15)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox30)
        Me.GroupBox_dependents.Controls.Add(Me.Label48)
        Me.GroupBox_dependents.Controls.Add(Me.Label49)
        Me.GroupBox_dependents.Controls.Add(Me.Label50)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox16)
        Me.GroupBox_dependents.Controls.Add(Me.Label51)
        Me.GroupBox_dependents.Controls.Add(Me.Label52)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox32)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox33)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox17)
        Me.GroupBox_dependents.Controls.Add(Me.Label53)
        Me.GroupBox_dependents.Controls.Add(Me.Label77)
        Me.GroupBox_dependents.Controls.Add(Me.Label78)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox18)
        Me.GroupBox_dependents.Controls.Add(Me.Label79)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox34)
        Me.GroupBox_dependents.Controls.Add(Me.Label80)
        Me.GroupBox_dependents.Controls.Add(Me.Label32)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox21)
        Me.GroupBox_dependents.Controls.Add(Me.Label33)
        Me.GroupBox_dependents.Controls.Add(Me.Label34)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox11)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox22)
        Me.GroupBox_dependents.Controls.Add(Me.Label35)
        Me.GroupBox_dependents.Controls.Add(Me.Label36)
        Me.GroupBox_dependents.Controls.Add(Me.Label37)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox12)
        Me.GroupBox_dependents.Controls.Add(Me.Label38)
        Me.GroupBox_dependents.Controls.Add(Me.Label39)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox24)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox25)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox13)
        Me.GroupBox_dependents.Controls.Add(Me.Label40)
        Me.GroupBox_dependents.Controls.Add(Me.Label41)
        Me.GroupBox_dependents.Controls.Add(Me.Label42)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox14)
        Me.GroupBox_dependents.Controls.Add(Me.Label43)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox26)
        Me.GroupBox_dependents.Controls.Add(Me.Label44)
        Me.GroupBox_dependents.Controls.Add(Me.Label19)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox12)
        Me.GroupBox_dependents.Controls.Add(Me.Label20)
        Me.GroupBox_dependents.Controls.Add(Me.Label21)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox7)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox14)
        Me.GroupBox_dependents.Controls.Add(Me.Label22)
        Me.GroupBox_dependents.Controls.Add(Me.Label23)
        Me.GroupBox_dependents.Controls.Add(Me.Label24)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox8)
        Me.GroupBox_dependents.Controls.Add(Me.Label25)
        Me.GroupBox_dependents.Controls.Add(Me.Label26)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox16)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox17)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox9)
        Me.GroupBox_dependents.Controls.Add(Me.Label27)
        Me.GroupBox_dependents.Controls.Add(Me.Label28)
        Me.GroupBox_dependents.Controls.Add(Me.Label29)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox10)
        Me.GroupBox_dependents.Controls.Add(Me.Label30)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox18)
        Me.GroupBox_dependents.Controls.Add(Me.Label31)
        Me.GroupBox_dependents.Controls.Add(Me.Label116)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox60)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox10)
        Me.GroupBox_dependents.Controls.Add(Me.Label18)
        Me.GroupBox_dependents.Controls.Add(Me.Label16)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox6)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox9)
        Me.GroupBox_dependents.Controls.Add(Me.Label12)
        Me.GroupBox_dependents.Controls.Add(Me.Label17)
        Me.GroupBox_dependents.Controls.Add(Me.Label11)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox5)
        Me.GroupBox_dependents.Controls.Add(Me.Label8)
        Me.GroupBox_dependents.Controls.Add(Me.Label10)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox3)
        Me.GroupBox_dependents.Controls.Add(Me.Label7)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox6)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox2)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox7)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox3)
        Me.GroupBox_dependents.Controls.Add(Me.Label6)
        Me.GroupBox_dependents.Controls.Add(Me.Label9)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox27)
        Me.GroupBox_dependents.Controls.Add(Me.Label3)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox20)
        Me.GroupBox_dependents.Controls.Add(Me.ComboBox4)
        Me.GroupBox_dependents.Controls.Add(Me.Label4)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox13)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox5)
        Me.GroupBox_dependents.Controls.Add(Me.Label5)
        Me.GroupBox_dependents.Controls.Add(Me.TextBox4)
        Me.GroupBox_dependents.Location = New System.Drawing.Point(532, 228)
        Me.GroupBox_dependents.Name = "GroupBox_dependents"
        Me.GroupBox_dependents.Size = New System.Drawing.Size(665, 512)
        Me.GroupBox_dependents.TabIndex = 195
        Me.GroupBox_dependents.TabStop = False
        Me.GroupBox_dependents.Text = "扶養家族情報"
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(88, 474)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(178, 19)
        Me.TextBox49.TabIndex = 578
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(88, 405)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(178, 19)
        Me.TextBox42.TabIndex = 577
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(88, 335)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(178, 19)
        Me.TextBox35.TabIndex = 576
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(88, 267)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(178, 19)
        Me.TextBox28.TabIndex = 575
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(88, 198)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(178, 19)
        Me.TextBox19.TabIndex = 574
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(88, 130)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(178, 19)
        Me.TextBox11.TabIndex = 573
        '
        'TextBox74
        '
        Me.TextBox74.Location = New System.Drawing.Point(247, 452)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(113, 19)
        Me.TextBox74.TabIndex = 572
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(247, 383)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(113, 19)
        Me.TextBox45.TabIndex = 571
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(247, 313)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(113, 19)
        Me.TextBox38.TabIndex = 570
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(247, 245)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(113, 19)
        Me.TextBox31.TabIndex = 569
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(247, 177)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(113, 19)
        Me.TextBox23.TabIndex = 568
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(247, 108)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(113, 19)
        Me.TextBox15.TabIndex = 567
        '
        'Label81
        '
        Me.Label81.AccessibleName = "-"
        Me.Label81.Location = New System.Drawing.Point(18, 475)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(64, 18)
        Me.Label81.TabIndex = 566
        Me.Label81.Text = "マイナンバー"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(604, 454)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(41, 19)
        Me.TextBox36.TabIndex = 564
        '
        'Label82
        '
        Me.Label82.AccessibleName = "-"
        Me.Label82.Location = New System.Drawing.Point(566, 455)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(32, 19)
        Me.Label82.TabIndex = 563
        Me.Label82.Text = "間柄"
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label83
        '
        Me.Label83.AccessibleName = "-"
        Me.Label83.Location = New System.Drawing.Point(449, 453)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(20, 19)
        Me.Label83.TabIndex = 562
        Me.Label83.Text = "歳"
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox19
        '
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(522, 454)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox19.TabIndex = 559
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(422, 453)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(21, 19)
        Me.TextBox37.TabIndex = 561
        '
        'Label84
        '
        Me.Label84.AccessibleName = "-"
        Me.Label84.Location = New System.Drawing.Point(475, 454)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(41, 19)
        Me.Label84.TabIndex = 558
        Me.Label84.Text = "性別"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label85
        '
        Me.Label85.AccessibleName = "-"
        Me.Label85.Location = New System.Drawing.Point(379, 453)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(37, 19)
        Me.Label85.TabIndex = 560
        Me.Label85.Text = "年齢"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label86
        '
        Me.Label86.AccessibleName = "-"
        Me.Label86.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label86.Location = New System.Drawing.Point(625, 431)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(20, 19)
        Me.Label86.TabIndex = 557
        Me.Label86.Text = "日"
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox20
        '
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(511, 431)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox20.TabIndex = 556
        '
        'Label87
        '
        Me.Label87.AccessibleName = "-"
        Me.Label87.Location = New System.Drawing.Point(555, 431)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(20, 19)
        Me.Label87.TabIndex = 555
        Me.Label87.Text = "月"
        Me.Label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label88
        '
        Me.Label88.AccessibleName = "-"
        Me.Label88.Location = New System.Drawing.Point(379, 432)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(56, 19)
        Me.Label88.TabIndex = 554
        Me.Label88.Text = "生年月日"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(223, 430)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(137, 19)
        Me.TextBox39.TabIndex = 549
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(87, 430)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(130, 19)
        Me.TextBox40.TabIndex = 546
        '
        'ComboBox21
        '
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(441, 431)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox21.TabIndex = 552
        '
        'Label89
        '
        Me.Label89.AccessibleName = "-"
        Me.Label89.Location = New System.Drawing.Point(18, 430)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(64, 18)
        Me.Label89.TabIndex = 545
        Me.Label89.Text = "フリガナ"
        Me.Label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label90
        '
        Me.Label90.AccessibleName = "-"
        Me.Label90.Location = New System.Drawing.Point(485, 432)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(20, 19)
        Me.Label90.TabIndex = 551
        Me.Label90.Text = "年"
        Me.Label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label91
        '
        Me.Label91.AccessibleName = "-"
        Me.Label91.Location = New System.Drawing.Point(223, 452)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(20, 19)
        Me.Label91.TabIndex = 550
        Me.Label91.Text = "名"
        Me.Label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox24
        '
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(581, 430)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox24.TabIndex = 544
        '
        'Label92
        '
        Me.Label92.AccessibleName = "-"
        Me.Label92.Location = New System.Drawing.Point(18, 453)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(64, 18)
        Me.Label92.TabIndex = 548
        Me.Label92.Text = "氏名"
        Me.Label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(113, 452)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(104, 19)
        Me.TextBox41.TabIndex = 547
        '
        'Label93
        '
        Me.Label93.AccessibleName = "-"
        Me.Label93.Location = New System.Drawing.Point(88, 452)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(20, 19)
        Me.Label93.TabIndex = 543
        Me.Label93.Text = "姓"
        Me.Label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label94
        '
        Me.Label94.AccessibleName = "-"
        Me.Label94.Location = New System.Drawing.Point(18, 406)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(64, 18)
        Me.Label94.TabIndex = 542
        Me.Label94.Text = "マイナンバー"
        Me.Label94.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(604, 385)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(41, 19)
        Me.TextBox43.TabIndex = 540
        '
        'Label95
        '
        Me.Label95.AccessibleName = "-"
        Me.Label95.Location = New System.Drawing.Point(566, 386)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(32, 19)
        Me.Label95.TabIndex = 539
        Me.Label95.Text = "間柄"
        Me.Label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label96
        '
        Me.Label96.AccessibleName = "-"
        Me.Label96.Location = New System.Drawing.Point(449, 384)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(20, 19)
        Me.Label96.TabIndex = 538
        Me.Label96.Text = "歳"
        Me.Label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox25
        '
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Location = New System.Drawing.Point(522, 385)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox25.TabIndex = 535
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(422, 384)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(21, 19)
        Me.TextBox44.TabIndex = 537
        '
        'Label97
        '
        Me.Label97.AccessibleName = "-"
        Me.Label97.Location = New System.Drawing.Point(475, 385)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(41, 19)
        Me.Label97.TabIndex = 534
        Me.Label97.Text = "性別"
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label98
        '
        Me.Label98.AccessibleName = "-"
        Me.Label98.Location = New System.Drawing.Point(379, 384)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(37, 19)
        Me.Label98.TabIndex = 536
        Me.Label98.Text = "年齢"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label99
        '
        Me.Label99.AccessibleName = "-"
        Me.Label99.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label99.Location = New System.Drawing.Point(625, 362)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(20, 19)
        Me.Label99.TabIndex = 533
        Me.Label99.Text = "日"
        Me.Label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox26
        '
        Me.ComboBox26.FormattingEnabled = True
        Me.ComboBox26.Location = New System.Drawing.Point(511, 362)
        Me.ComboBox26.Name = "ComboBox26"
        Me.ComboBox26.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox26.TabIndex = 532
        '
        'Label100
        '
        Me.Label100.AccessibleName = "-"
        Me.Label100.Location = New System.Drawing.Point(555, 362)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(20, 19)
        Me.Label100.TabIndex = 531
        Me.Label100.Text = "月"
        Me.Label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label101
        '
        Me.Label101.AccessibleName = "-"
        Me.Label101.Location = New System.Drawing.Point(379, 363)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(56, 19)
        Me.Label101.TabIndex = 530
        Me.Label101.Text = "生年月日"
        Me.Label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(223, 361)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(137, 19)
        Me.TextBox46.TabIndex = 525
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(87, 361)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(130, 19)
        Me.TextBox47.TabIndex = 522
        '
        'ComboBox27
        '
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Location = New System.Drawing.Point(441, 362)
        Me.ComboBox27.Name = "ComboBox27"
        Me.ComboBox27.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox27.TabIndex = 528
        '
        'Label102
        '
        Me.Label102.AccessibleName = "-"
        Me.Label102.Location = New System.Drawing.Point(18, 361)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(64, 18)
        Me.Label102.TabIndex = 521
        Me.Label102.Text = "フリガナ"
        Me.Label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label103
        '
        Me.Label103.AccessibleName = "-"
        Me.Label103.Location = New System.Drawing.Point(485, 363)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(20, 19)
        Me.Label103.TabIndex = 527
        Me.Label103.Text = "年"
        Me.Label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label104
        '
        Me.Label104.AccessibleName = "-"
        Me.Label104.Location = New System.Drawing.Point(223, 383)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(20, 19)
        Me.Label104.TabIndex = 526
        Me.Label104.Text = "名"
        Me.Label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox28
        '
        Me.ComboBox28.FormattingEnabled = True
        Me.ComboBox28.Location = New System.Drawing.Point(581, 361)
        Me.ComboBox28.Name = "ComboBox28"
        Me.ComboBox28.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox28.TabIndex = 520
        '
        'Label105
        '
        Me.Label105.AccessibleName = "-"
        Me.Label105.Location = New System.Drawing.Point(18, 384)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(64, 18)
        Me.Label105.TabIndex = 524
        Me.Label105.Text = "氏名"
        Me.Label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(113, 383)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(104, 19)
        Me.TextBox48.TabIndex = 523
        '
        'Label106
        '
        Me.Label106.AccessibleName = "-"
        Me.Label106.Location = New System.Drawing.Point(88, 383)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(20, 19)
        Me.Label106.TabIndex = 519
        Me.Label106.Text = "姓"
        Me.Label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label107
        '
        Me.Label107.AccessibleName = "-"
        Me.Label107.Location = New System.Drawing.Point(18, 336)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(64, 18)
        Me.Label107.TabIndex = 518
        Me.Label107.Text = "マイナンバー"
        Me.Label107.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox72
        '
        Me.TextBox72.Location = New System.Drawing.Point(604, 315)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(41, 19)
        Me.TextBox72.TabIndex = 516
        '
        'Label108
        '
        Me.Label108.AccessibleName = "-"
        Me.Label108.Location = New System.Drawing.Point(566, 316)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(32, 19)
        Me.Label108.TabIndex = 515
        Me.Label108.Text = "間柄"
        Me.Label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label109
        '
        Me.Label109.AccessibleName = "-"
        Me.Label109.Location = New System.Drawing.Point(449, 314)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(20, 19)
        Me.Label109.TabIndex = 514
        Me.Label109.Text = "歳"
        Me.Label109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox29
        '
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Location = New System.Drawing.Point(522, 315)
        Me.ComboBox29.Name = "ComboBox29"
        Me.ComboBox29.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox29.TabIndex = 511
        '
        'TextBox73
        '
        Me.TextBox73.Location = New System.Drawing.Point(422, 314)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(21, 19)
        Me.TextBox73.TabIndex = 513
        '
        'Label110
        '
        Me.Label110.AccessibleName = "-"
        Me.Label110.Location = New System.Drawing.Point(475, 315)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(41, 19)
        Me.Label110.TabIndex = 510
        Me.Label110.Text = "性別"
        Me.Label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label111
        '
        Me.Label111.AccessibleName = "-"
        Me.Label111.Location = New System.Drawing.Point(379, 314)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(37, 19)
        Me.Label111.TabIndex = 512
        Me.Label111.Text = "年齢"
        Me.Label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label112
        '
        Me.Label112.AccessibleName = "-"
        Me.Label112.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label112.Location = New System.Drawing.Point(625, 292)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(20, 19)
        Me.Label112.TabIndex = 509
        Me.Label112.Text = "日"
        Me.Label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox30
        '
        Me.ComboBox30.FormattingEnabled = True
        Me.ComboBox30.Location = New System.Drawing.Point(511, 292)
        Me.ComboBox30.Name = "ComboBox30"
        Me.ComboBox30.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox30.TabIndex = 508
        '
        'Label113
        '
        Me.Label113.AccessibleName = "-"
        Me.Label113.Location = New System.Drawing.Point(555, 292)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(20, 19)
        Me.Label113.TabIndex = 507
        Me.Label113.Text = "月"
        Me.Label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label130
        '
        Me.Label130.AccessibleName = "-"
        Me.Label130.Location = New System.Drawing.Point(379, 293)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(56, 19)
        Me.Label130.TabIndex = 506
        Me.Label130.Text = "生年月日"
        Me.Label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox75
        '
        Me.TextBox75.Location = New System.Drawing.Point(223, 291)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(137, 19)
        Me.TextBox75.TabIndex = 501
        '
        'TextBox76
        '
        Me.TextBox76.Location = New System.Drawing.Point(87, 291)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(130, 19)
        Me.TextBox76.TabIndex = 498
        '
        'ComboBox31
        '
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Location = New System.Drawing.Point(441, 292)
        Me.ComboBox31.Name = "ComboBox31"
        Me.ComboBox31.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox31.TabIndex = 504
        '
        'Label131
        '
        Me.Label131.AccessibleName = "-"
        Me.Label131.Location = New System.Drawing.Point(18, 291)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(64, 18)
        Me.Label131.TabIndex = 497
        Me.Label131.Text = "フリガナ"
        Me.Label131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label132
        '
        Me.Label132.AccessibleName = "-"
        Me.Label132.Location = New System.Drawing.Point(485, 293)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(20, 19)
        Me.Label132.TabIndex = 503
        Me.Label132.Text = "年"
        Me.Label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label133
        '
        Me.Label133.AccessibleName = "-"
        Me.Label133.Location = New System.Drawing.Point(223, 313)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(20, 19)
        Me.Label133.TabIndex = 502
        Me.Label133.Text = "名"
        Me.Label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox32
        '
        Me.ComboBox32.FormattingEnabled = True
        Me.ComboBox32.Location = New System.Drawing.Point(581, 291)
        Me.ComboBox32.Name = "ComboBox32"
        Me.ComboBox32.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox32.TabIndex = 496
        '
        'Label134
        '
        Me.Label134.AccessibleName = "-"
        Me.Label134.Location = New System.Drawing.Point(18, 314)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(64, 18)
        Me.Label134.TabIndex = 500
        Me.Label134.Text = "氏名"
        Me.Label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox77
        '
        Me.TextBox77.Location = New System.Drawing.Point(113, 313)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(104, 19)
        Me.TextBox77.TabIndex = 499
        '
        'Label135
        '
        Me.Label135.AccessibleName = "-"
        Me.Label135.Location = New System.Drawing.Point(88, 313)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(20, 19)
        Me.Label135.TabIndex = 495
        Me.Label135.Text = "姓"
        Me.Label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.AccessibleName = "-"
        Me.Label45.Location = New System.Drawing.Point(18, 268)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(64, 18)
        Me.Label45.TabIndex = 494
        Me.Label45.Text = "マイナンバー"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(604, 247)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(41, 19)
        Me.TextBox29.TabIndex = 492
        '
        'Label46
        '
        Me.Label46.AccessibleName = "-"
        Me.Label46.Location = New System.Drawing.Point(566, 248)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(32, 19)
        Me.Label46.TabIndex = 491
        Me.Label46.Text = "間柄"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.AccessibleName = "-"
        Me.Label47.Location = New System.Drawing.Point(449, 246)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(20, 19)
        Me.Label47.TabIndex = 490
        Me.Label47.Text = "歳"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(522, 247)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox15.TabIndex = 487
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(422, 246)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(21, 19)
        Me.TextBox30.TabIndex = 489
        '
        'Label48
        '
        Me.Label48.AccessibleName = "-"
        Me.Label48.Location = New System.Drawing.Point(475, 247)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(41, 19)
        Me.Label48.TabIndex = 486
        Me.Label48.Text = "性別"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.AccessibleName = "-"
        Me.Label49.Location = New System.Drawing.Point(379, 246)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(37, 19)
        Me.Label49.TabIndex = 488
        Me.Label49.Text = "年齢"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label50
        '
        Me.Label50.AccessibleName = "-"
        Me.Label50.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label50.Location = New System.Drawing.Point(625, 224)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(20, 19)
        Me.Label50.TabIndex = 485
        Me.Label50.Text = "日"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(511, 224)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox16.TabIndex = 484
        '
        'Label51
        '
        Me.Label51.AccessibleName = "-"
        Me.Label51.Location = New System.Drawing.Point(555, 224)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(20, 19)
        Me.Label51.TabIndex = 483
        Me.Label51.Text = "月"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label52
        '
        Me.Label52.AccessibleName = "-"
        Me.Label52.Location = New System.Drawing.Point(379, 225)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(56, 19)
        Me.Label52.TabIndex = 482
        Me.Label52.Text = "生年月日"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(223, 223)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(137, 19)
        Me.TextBox32.TabIndex = 477
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(87, 223)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(130, 19)
        Me.TextBox33.TabIndex = 474
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(441, 224)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox17.TabIndex = 480
        '
        'Label53
        '
        Me.Label53.AccessibleName = "-"
        Me.Label53.Location = New System.Drawing.Point(18, 223)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(64, 18)
        Me.Label53.TabIndex = 473
        Me.Label53.Text = "フリガナ"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label77
        '
        Me.Label77.AccessibleName = "-"
        Me.Label77.Location = New System.Drawing.Point(485, 225)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(20, 19)
        Me.Label77.TabIndex = 479
        Me.Label77.Text = "年"
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label78
        '
        Me.Label78.AccessibleName = "-"
        Me.Label78.Location = New System.Drawing.Point(223, 245)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(20, 19)
        Me.Label78.TabIndex = 478
        Me.Label78.Text = "名"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(581, 223)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox18.TabIndex = 472
        '
        'Label79
        '
        Me.Label79.AccessibleName = "-"
        Me.Label79.Location = New System.Drawing.Point(18, 246)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(64, 18)
        Me.Label79.TabIndex = 476
        Me.Label79.Text = "氏名"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(113, 245)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(104, 19)
        Me.TextBox34.TabIndex = 475
        '
        'Label80
        '
        Me.Label80.AccessibleName = "-"
        Me.Label80.Location = New System.Drawing.Point(88, 245)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(20, 19)
        Me.Label80.TabIndex = 471
        Me.Label80.Text = "姓"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.AccessibleName = "-"
        Me.Label32.Location = New System.Drawing.Point(18, 199)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(64, 18)
        Me.Label32.TabIndex = 470
        Me.Label32.Text = "マイナンバー"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(604, 179)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(41, 19)
        Me.TextBox21.TabIndex = 468
        '
        'Label33
        '
        Me.Label33.AccessibleName = "-"
        Me.Label33.Location = New System.Drawing.Point(566, 180)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(32, 19)
        Me.Label33.TabIndex = 467
        Me.Label33.Text = "間柄"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label34
        '
        Me.Label34.AccessibleName = "-"
        Me.Label34.Location = New System.Drawing.Point(449, 178)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(20, 19)
        Me.Label34.TabIndex = 466
        Me.Label34.Text = "歳"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(522, 179)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox11.TabIndex = 463
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(422, 178)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(21, 19)
        Me.TextBox22.TabIndex = 465
        '
        'Label35
        '
        Me.Label35.AccessibleName = "-"
        Me.Label35.Location = New System.Drawing.Point(475, 179)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(41, 19)
        Me.Label35.TabIndex = 462
        Me.Label35.Text = "性別"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label36
        '
        Me.Label36.AccessibleName = "-"
        Me.Label36.Location = New System.Drawing.Point(379, 178)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(37, 19)
        Me.Label36.TabIndex = 464
        Me.Label36.Text = "年齢"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label37
        '
        Me.Label37.AccessibleName = "-"
        Me.Label37.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label37.Location = New System.Drawing.Point(625, 156)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(20, 19)
        Me.Label37.TabIndex = 461
        Me.Label37.Text = "日"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(511, 156)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox12.TabIndex = 460
        '
        'Label38
        '
        Me.Label38.AccessibleName = "-"
        Me.Label38.Location = New System.Drawing.Point(555, 156)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(20, 19)
        Me.Label38.TabIndex = 459
        Me.Label38.Text = "月"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.AccessibleName = "-"
        Me.Label39.Location = New System.Drawing.Point(379, 157)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(56, 19)
        Me.Label39.TabIndex = 458
        Me.Label39.Text = "生年月日"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(223, 155)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(137, 19)
        Me.TextBox24.TabIndex = 453
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(87, 155)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(130, 19)
        Me.TextBox25.TabIndex = 450
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(441, 156)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox13.TabIndex = 456
        '
        'Label40
        '
        Me.Label40.AccessibleName = "-"
        Me.Label40.Location = New System.Drawing.Point(18, 155)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(64, 18)
        Me.Label40.TabIndex = 449
        Me.Label40.Text = "フリガナ"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.AccessibleName = "-"
        Me.Label41.Location = New System.Drawing.Point(485, 157)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(20, 19)
        Me.Label41.TabIndex = 455
        Me.Label41.Text = "年"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.AccessibleName = "-"
        Me.Label42.Location = New System.Drawing.Point(223, 177)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(20, 19)
        Me.Label42.TabIndex = 454
        Me.Label42.Text = "名"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(581, 155)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox14.TabIndex = 448
        '
        'Label43
        '
        Me.Label43.AccessibleName = "-"
        Me.Label43.Location = New System.Drawing.Point(18, 178)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(64, 18)
        Me.Label43.TabIndex = 452
        Me.Label43.Text = "氏名"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(113, 177)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(104, 19)
        Me.TextBox26.TabIndex = 451
        '
        'Label44
        '
        Me.Label44.AccessibleName = "-"
        Me.Label44.Location = New System.Drawing.Point(88, 177)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(20, 19)
        Me.Label44.TabIndex = 447
        Me.Label44.Text = "姓"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.AccessibleName = "-"
        Me.Label19.Location = New System.Drawing.Point(18, 130)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(64, 18)
        Me.Label19.TabIndex = 446
        Me.Label19.Text = "マイナンバー"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(604, 110)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(41, 19)
        Me.TextBox12.TabIndex = 444
        '
        'Label20
        '
        Me.Label20.AccessibleName = "-"
        Me.Label20.Location = New System.Drawing.Point(566, 111)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(32, 19)
        Me.Label20.TabIndex = 443
        Me.Label20.Text = "間柄"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AccessibleName = "-"
        Me.Label21.Location = New System.Drawing.Point(449, 109)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(20, 19)
        Me.Label21.TabIndex = 442
        Me.Label21.Text = "歳"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(522, 110)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox7.TabIndex = 439
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(422, 109)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(21, 19)
        Me.TextBox14.TabIndex = 441
        '
        'Label22
        '
        Me.Label22.AccessibleName = "-"
        Me.Label22.Location = New System.Drawing.Point(475, 110)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(41, 19)
        Me.Label22.TabIndex = 438
        Me.Label22.Text = "性別"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AccessibleName = "-"
        Me.Label23.Location = New System.Drawing.Point(379, 109)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(37, 19)
        Me.Label23.TabIndex = 440
        Me.Label23.Text = "年齢"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.AccessibleName = "-"
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Location = New System.Drawing.Point(625, 87)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(20, 19)
        Me.Label24.TabIndex = 437
        Me.Label24.Text = "日"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(511, 87)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox8.TabIndex = 436
        '
        'Label25
        '
        Me.Label25.AccessibleName = "-"
        Me.Label25.Location = New System.Drawing.Point(555, 87)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(20, 19)
        Me.Label25.TabIndex = 435
        Me.Label25.Text = "月"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.AccessibleName = "-"
        Me.Label26.Location = New System.Drawing.Point(379, 88)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(56, 19)
        Me.Label26.TabIndex = 434
        Me.Label26.Text = "生年月日"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(223, 86)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(137, 19)
        Me.TextBox16.TabIndex = 429
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(87, 86)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(130, 19)
        Me.TextBox17.TabIndex = 426
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(441, 87)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox9.TabIndex = 432
        '
        'Label27
        '
        Me.Label27.AccessibleName = "-"
        Me.Label27.Location = New System.Drawing.Point(18, 86)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(64, 18)
        Me.Label27.TabIndex = 425
        Me.Label27.Text = "フリガナ"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AccessibleName = "-"
        Me.Label28.Location = New System.Drawing.Point(485, 88)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(20, 19)
        Me.Label28.TabIndex = 431
        Me.Label28.Text = "年"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.AccessibleName = "-"
        Me.Label29.Location = New System.Drawing.Point(223, 108)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(20, 19)
        Me.Label29.TabIndex = 430
        Me.Label29.Text = "名"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(581, 86)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox10.TabIndex = 424
        '
        'Label30
        '
        Me.Label30.AccessibleName = "-"
        Me.Label30.Location = New System.Drawing.Point(18, 109)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(64, 18)
        Me.Label30.TabIndex = 428
        Me.Label30.Text = "氏名"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(113, 108)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(104, 19)
        Me.TextBox18.TabIndex = 427
        '
        'Label31
        '
        Me.Label31.AccessibleName = "-"
        Me.Label31.Location = New System.Drawing.Point(88, 108)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(20, 19)
        Me.Label31.TabIndex = 423
        Me.Label31.Text = "姓"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label116
        '
        Me.Label116.AccessibleName = "-"
        Me.Label116.Location = New System.Drawing.Point(18, 62)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(64, 18)
        Me.Label116.TabIndex = 422
        Me.Label116.Text = "マイナンバー"
        Me.Label116.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(88, 61)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(178, 19)
        Me.TextBox60.TabIndex = 421
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(604, 42)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(41, 19)
        Me.TextBox10.TabIndex = 264
        '
        'Label18
        '
        Me.Label18.AccessibleName = "-"
        Me.Label18.Location = New System.Drawing.Point(566, 43)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(32, 19)
        Me.Label18.TabIndex = 263
        Me.Label18.Text = "間柄"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AccessibleName = "-"
        Me.Label16.Location = New System.Drawing.Point(449, 41)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 19)
        Me.Label16.TabIndex = 262
        Me.Label16.Text = "歳"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(522, 42)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox6.TabIndex = 255
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(422, 41)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(21, 19)
        Me.TextBox9.TabIndex = 261
        '
        'Label12
        '
        Me.Label12.AccessibleName = "-"
        Me.Label12.Location = New System.Drawing.Point(475, 42)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 19)
        Me.Label12.TabIndex = 254
        Me.Label12.Text = "性別"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.AccessibleName = "-"
        Me.Label17.Location = New System.Drawing.Point(379, 41)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 19)
        Me.Label17.TabIndex = 259
        Me.Label17.Text = "年齢"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AccessibleName = "-"
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Location = New System.Drawing.Point(625, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(20, 19)
        Me.Label11.TabIndex = 253
        Me.Label11.Text = "日"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(511, 18)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox5.TabIndex = 252
        '
        'Label8
        '
        Me.Label8.AccessibleName = "-"
        Me.Label8.Location = New System.Drawing.Point(555, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(20, 19)
        Me.Label8.TabIndex = 251
        Me.Label8.Text = "月"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.AccessibleName = "-"
        Me.Label10.Location = New System.Drawing.Point(379, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 19)
        Me.Label10.TabIndex = 250
        Me.Label10.Text = "生年月日"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(247, 40)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(113, 19)
        Me.TextBox3.TabIndex = 249
        '
        'Label7
        '
        Me.Label7.AccessibleName = "-"
        Me.Label7.Location = New System.Drawing.Point(711, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(20, 19)
        Me.Label7.TabIndex = 248
        Me.Label7.Text = "日"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(223, 18)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(137, 19)
        Me.TextBox6.TabIndex = 243
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(667, 19)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox2.TabIndex = 247
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(87, 18)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(130, 19)
        Me.TextBox7.TabIndex = 242
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(441, 18)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox3.TabIndex = 245
        '
        'Label6
        '
        Me.Label6.AccessibleName = "-"
        Me.Label6.Location = New System.Drawing.Point(18, 18)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 18)
        Me.Label6.TabIndex = 241
        Me.Label6.Text = "フリガナ"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AccessibleName = "-"
        Me.Label9.Location = New System.Drawing.Point(485, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(20, 19)
        Me.Label9.TabIndex = 244
        Me.Label9.Text = "年"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(-93, -67)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(110, 19)
        Me.TextBox27.TabIndex = 174
        '
        'Label3
        '
        Me.Label3.AccessibleName = "-"
        Me.Label3.Location = New System.Drawing.Point(223, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 19)
        Me.Label3.TabIndex = 244
        Me.Label3.Text = "名"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(-93, -114)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(110, 19)
        Me.TextBox20.TabIndex = 156
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(581, 18)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox4.TabIndex = 241
        '
        'Label4
        '
        Me.Label4.AccessibleName = "-"
        Me.Label4.Location = New System.Drawing.Point(18, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 18)
        Me.Label4.TabIndex = 243
        Me.Label4.Text = "氏名"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(-91, -161)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(110, 19)
        Me.TextBox13.TabIndex = 138
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(113, 40)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(104, 19)
        Me.TextBox5.TabIndex = 242
        '
        'Label5
        '
        Me.Label5.AccessibleName = "-"
        Me.Label5.Location = New System.Drawing.Point(88, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(20, 19)
        Me.Label5.TabIndex = 241
        Me.Label5.Text = "姓"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(-93, -208)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(110, 19)
        Me.TextBox4.TabIndex = 120
        '
        'Button_pictselect
        '
        Me.Button_pictselect.Location = New System.Drawing.Point(1043, 201)
        Me.Button_pictselect.Name = "Button_pictselect"
        Me.Button_pictselect.Size = New System.Drawing.Size(75, 23)
        Me.Button_pictselect.TabIndex = 119
        Me.Button_pictselect.Text = "画像選択"
        Me.Button_pictselect.UseVisualStyleBackColor = True
        '
        'Label_retire
        '
        Me.Label_retire.Location = New System.Drawing.Point(893, 57)
        Me.Label_retire.Name = "Label_retire"
        Me.Label_retire.Size = New System.Drawing.Size(76, 19)
        Me.Label_retire.TabIndex = 118
        Me.Label_retire.Text = "退職日"
        Me.Label_retire.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_belong
        '
        Me.Label_belong.Location = New System.Drawing.Point(380, 56)
        Me.Label_belong.Name = "Label_belong"
        Me.Label_belong.Size = New System.Drawing.Size(76, 19)
        Me.Label_belong.TabIndex = 116
        Me.Label_belong.Text = "所属部署"
        Me.Label_belong.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_belong
        '
        Me.TextBox_belong.Location = New System.Drawing.Point(379, 79)
        Me.TextBox_belong.Name = "TextBox_belong"
        Me.TextBox_belong.Size = New System.Drawing.Size(192, 19)
        Me.TextBox_belong.TabIndex = 115
        '
        'Label_joindate
        '
        Me.Label_joindate.Location = New System.Drawing.Point(760, 56)
        Me.Label_joindate.Name = "Label_joindate"
        Me.Label_joindate.Size = New System.Drawing.Size(76, 19)
        Me.Label_joindate.TabIndex = 114
        Me.Label_joindate.Text = "入社日"
        Me.Label_joindate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_joindate
        '
        Me.TextBox_joindate.Location = New System.Drawing.Point(760, 79)
        Me.TextBox_joindate.Name = "TextBox_joindate"
        Me.TextBox_joindate.Size = New System.Drawing.Size(115, 19)
        Me.TextBox_joindate.TabIndex = 113
        '
        'TextBox_retire
        '
        Me.TextBox_retire.Location = New System.Drawing.Point(892, 79)
        Me.TextBox_retire.Name = "TextBox_retire"
        Me.TextBox_retire.Size = New System.Drawing.Size(115, 19)
        Me.TextBox_retire.TabIndex = 117
        '
        'Label_company
        '
        Me.Label_company.Location = New System.Drawing.Point(19, 58)
        Me.Label_company.Name = "Label_company"
        Me.Label_company.Size = New System.Drawing.Size(76, 19)
        Me.Label_company.TabIndex = 112
        Me.Label_company.Text = "会社名"
        Me.Label_company.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_Company
        '
        Me.TextBox_Company.Location = New System.Drawing.Point(17, 80)
        Me.TextBox_Company.Name = "TextBox_Company"
        Me.TextBox_Company.Size = New System.Drawing.Size(345, 19)
        Me.TextBox_Company.TabIndex = 111
        Me.TextBox_Company.Text = "株式会社アップワードホールディングス"
        '
        'PictureBox
        '
        Me.PictureBox.Location = New System.Drawing.Point(1043, 56)
        Me.PictureBox.Name = "PictureBox"
        Me.PictureBox.Size = New System.Drawing.Size(154, 143)
        Me.PictureBox.TabIndex = 110
        Me.PictureBox.TabStop = False
        '
        'Button_delete
        '
        Me.Button_delete.Location = New System.Drawing.Point(340, 17)
        Me.Button_delete.Name = "Button_delete"
        Me.Button_delete.Size = New System.Drawing.Size(80, 23)
        Me.Button_delete.TabIndex = 109
        Me.Button_delete.Text = "削除"
        Me.Button_delete.UseVisualStyleBackColor = True
        '
        'Button_update
        '
        Me.Button_update.Location = New System.Drawing.Point(245, 16)
        Me.Button_update.Name = "Button_update"
        Me.Button_update.Size = New System.Drawing.Size(80, 23)
        Me.Button_update.TabIndex = 108
        Me.Button_update.Text = "編集"
        Me.Button_update.UseVisualStyleBackColor = True
        '
        'Button_insert
        '
        Me.Button_insert.Location = New System.Drawing.Point(150, 16)
        Me.Button_insert.Name = "Button_insert"
        Me.Button_insert.Size = New System.Drawing.Size(80, 23)
        Me.Button_insert.TabIndex = 107
        Me.Button_insert.Text = "登録"
        Me.Button_insert.UseVisualStyleBackColor = True
        '
        'Button_select
        '
        Me.Button_select.AccessibleRole = System.Windows.Forms.AccessibleRole.Caret
        Me.Button_select.Location = New System.Drawing.Point(17, 17)
        Me.Button_select.Name = "Button_select"
        Me.Button_select.Size = New System.Drawing.Size(116, 23)
        Me.Button_select.TabIndex = 106
        Me.Button_select.Text = "社員リスト参照"
        Me.Button_select.UseVisualStyleBackColor = True
        '
        'TextBox_address1kana
        '
        Me.TextBox_address1kana.Location = New System.Drawing.Point(101, 384)
        Me.TextBox_address1kana.Name = "TextBox_address1kana"
        Me.TextBox_address1kana.Size = New System.Drawing.Size(336, 19)
        Me.TextBox_address1kana.TabIndex = 159
        '
        'ComboBox_Pref
        '
        Me.ComboBox_Pref.FormattingEnabled = True
        Me.ComboBox_Pref.Location = New System.Drawing.Point(100, 359)
        Me.ComboBox_Pref.Name = "ComboBox_Pref"
        Me.ComboBox_Pref.Size = New System.Drawing.Size(115, 20)
        Me.ComboBox_Pref.TabIndex = 158
        '
        'ComboBox_sex
        '
        Me.ComboBox_sex.FormattingEnabled = True
        Me.ComboBox_sex.Location = New System.Drawing.Point(94, 158)
        Me.ComboBox_sex.Name = "ComboBox_sex"
        Me.ComboBox_sex.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox_sex.TabIndex = 156
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(100, 310)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(281, 19)
        Me.TextBox1.TabIndex = 155
        '
        'Button_pictupload
        '
        Me.Button_pictupload.Location = New System.Drawing.Point(1123, 201)
        Me.Button_pictupload.Name = "Button_pictupload"
        Me.Button_pictupload.Size = New System.Drawing.Size(75, 23)
        Me.Button_pictupload.TabIndex = 120
        Me.Button_pictupload.Text = "アップロード"
        Me.Button_pictupload.UseVisualStyleBackColor = True
        '
        'TextBox_lastnamekana
        '
        Me.TextBox_lastnamekana.Location = New System.Drawing.Point(121, 137)
        Me.TextBox_lastnamekana.Name = "TextBox_lastnamekana"
        Me.TextBox_lastnamekana.Size = New System.Drawing.Size(125, 19)
        Me.TextBox_lastnamekana.TabIndex = 127
        '
        'Label_lastname
        '
        Me.Label_lastname.AccessibleName = "-"
        Me.Label_lastname.Location = New System.Drawing.Point(95, 137)
        Me.Label_lastname.Name = "Label_lastname"
        Me.Label_lastname.Size = New System.Drawing.Size(20, 19)
        Me.Label_lastname.TabIndex = 126
        Me.Label_lastname.Text = "姓"
        Me.Label_lastname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_lastupdate
        '
        Me.Label_lastupdate.AccessibleName = "-"
        Me.Label_lastupdate.Location = New System.Drawing.Point(987, 19)
        Me.Label_lastupdate.Name = "Label_lastupdate"
        Me.Label_lastupdate.Size = New System.Drawing.Size(95, 18)
        Me.Label_lastupdate.TabIndex = 124
        Me.Label_lastupdate.Text = "最終更新日時"
        Me.Label_lastupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_nowdate
        '
        Me.Label_nowdate.AccessibleName = "-"
        Me.Label_nowdate.Location = New System.Drawing.Point(874, 19)
        Me.Label_nowdate.Name = "Label_nowdate"
        Me.Label_nowdate.Size = New System.Drawing.Size(95, 18)
        Me.Label_nowdate.TabIndex = 123
        Me.Label_nowdate.Text = "当日の日付"
        Me.Label_nowdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox_empnum
        '
        Me.TextBox_empnum.Location = New System.Drawing.Point(589, 79)
        Me.TextBox_empnum.Name = "TextBox_empnum"
        Me.TextBox_empnum.Size = New System.Drawing.Size(151, 19)
        Me.TextBox_empnum.TabIndex = 121
        '
        'Label_empnum
        '
        Me.Label_empnum.AccessibleName = "-"
        Me.Label_empnum.Location = New System.Drawing.Point(589, 56)
        Me.Label_empnum.Name = "Label_empnum"
        Me.Label_empnum.Size = New System.Drawing.Size(76, 19)
        Me.Label_empnum.TabIndex = 122
        Me.Label_empnum.Text = "社員番号"
        Me.Label_empnum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_birthyear
        '
        Me.TextBox_birthyear.Location = New System.Drawing.Point(137, 189)
        Me.TextBox_birthyear.Name = "TextBox_birthyear"
        Me.TextBox_birthyear.Size = New System.Drawing.Size(38, 19)
        Me.TextBox_birthyear.TabIndex = 135
        '
        'ComboBox_nengou
        '
        Me.ComboBox_nengou.FormattingEnabled = True
        Me.ComboBox_nengou.Location = New System.Drawing.Point(94, 189)
        Me.ComboBox_nengou.Name = "ComboBox_nengou"
        Me.ComboBox_nengou.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox_nengou.TabIndex = 133
        '
        'TextBox_telnumber1
        '
        Me.TextBox_telnumber1.Location = New System.Drawing.Point(100, 285)
        Me.TextBox_telnumber1.Name = "TextBox_telnumber1"
        Me.TextBox_telnumber1.Size = New System.Drawing.Size(70, 19)
        Me.TextBox_telnumber1.TabIndex = 143
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(418, 136)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(76, 19)
        Me.TextBox52.TabIndex = 204
        '
        'Label55
        '
        Me.Label55.AccessibleName = "-"
        Me.Label55.Location = New System.Drawing.Point(418, 114)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(76, 19)
        Me.Label55.TabIndex = 203
        Me.Label55.Text = "社交番号"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(589, 113)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(151, 19)
        Me.TextBox53.TabIndex = 205
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(589, 137)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(151, 19)
        Me.TextBox54.TabIndex = 207
        '
        'Label57
        '
        Me.Label57.AccessibleName = "-"
        Me.Label57.Location = New System.Drawing.Point(513, 113)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(70, 19)
        Me.Label57.TabIndex = 208
        Me.Label57.Text = "フリガナ"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label58
        '
        Me.Label58.AccessibleName = "-"
        Me.Label58.Location = New System.Drawing.Point(513, 136)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(70, 19)
        Me.Label58.TabIndex = 209
        Me.Label58.Text = "社交名"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label56
        '
        Me.Label56.AccessibleName = "-"
        Me.Label56.Location = New System.Drawing.Point(19, 113)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(70, 19)
        Me.Label56.TabIndex = 210
        Me.Label56.Text = "フリガナ"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label59
        '
        Me.Label59.AccessibleName = "-"
        Me.Label59.Location = New System.Drawing.Point(19, 136)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(70, 19)
        Me.Label59.TabIndex = 211
        Me.Label59.Text = "氏名"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(95, 113)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(151, 19)
        Me.TextBox55.TabIndex = 212
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(252, 113)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(147, 19)
        Me.TextBox56.TabIndex = 213
        '
        'Label60
        '
        Me.Label60.AccessibleName = "-"
        Me.Label60.Location = New System.Drawing.Point(252, 137)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(20, 19)
        Me.Label60.TabIndex = 214
        Me.Label60.Text = "名"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(278, 137)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(121, 19)
        Me.TextBox57.TabIndex = 215
        '
        'Label61
        '
        Me.Label61.AccessibleName = "-"
        Me.Label61.Location = New System.Drawing.Point(19, 159)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(70, 19)
        Me.Label61.TabIndex = 216
        Me.Label61.Text = "性別"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label62
        '
        Me.Label62.AccessibleName = "-"
        Me.Label62.Location = New System.Drawing.Point(19, 190)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(70, 19)
        Me.Label62.TabIndex = 217
        Me.Label62.Text = "生年月日"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label63
        '
        Me.Label63.AccessibleName = "-"
        Me.Label63.Location = New System.Drawing.Point(180, 190)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(20, 19)
        Me.Label63.TabIndex = 218
        Me.Label63.Text = "年"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.AccessibleName = "-"
        Me.Label64.Location = New System.Drawing.Point(251, 190)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(20, 19)
        Me.Label64.TabIndex = 220
        Me.Label64.Text = "月"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label65
        '
        Me.Label65.AccessibleName = "-"
        Me.Label65.Location = New System.Drawing.Point(321, 190)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(20, 19)
        Me.Label65.TabIndex = 222
        Me.Label65.Text = "日"
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox23
        '
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Location = New System.Drawing.Point(277, 189)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(40, 20)
        Me.ComboBox23.TabIndex = 221
        '
        'Label66
        '
        Me.Label66.AccessibleName = "-"
        Me.Label66.Location = New System.Drawing.Point(18, 285)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(76, 19)
        Me.Label66.TabIndex = 223
        Me.Label66.Text = "電話番号"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label67
        '
        Me.Label67.AccessibleName = "-"
        Me.Label67.Location = New System.Drawing.Point(176, 285)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(20, 19)
        Me.Label67.TabIndex = 224
        Me.Label67.Text = "-"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label68
        '
        Me.Label68.AccessibleName = "-"
        Me.Label68.Location = New System.Drawing.Point(276, 285)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(20, 19)
        Me.Label68.TabIndex = 227
        Me.Label68.Text = "-"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label69
        '
        Me.Label69.AccessibleName = "-"
        Me.Label69.Location = New System.Drawing.Point(18, 309)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(76, 19)
        Me.Label69.TabIndex = 228
        Me.Label69.Text = "メールアドレス"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label70
        '
        Me.Label70.AccessibleName = "-"
        Me.Label70.Location = New System.Drawing.Point(19, 336)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(76, 19)
        Me.Label70.TabIndex = 229
        Me.Label70.Text = "郵便番号"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label71
        '
        Me.Label71.AccessibleName = "-"
        Me.Label71.Location = New System.Drawing.Point(164, 336)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(20, 19)
        Me.Label71.TabIndex = 231
        Me.Label71.Text = "-"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(101, 336)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(58, 19)
        Me.TextBox61.TabIndex = 230
        '
        'Label72
        '
        Me.Label72.AccessibleName = "-"
        Me.Label72.Location = New System.Drawing.Point(19, 360)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(76, 19)
        Me.Label72.TabIndex = 233
        Me.Label72.Text = "都道府県"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label73
        '
        Me.Label73.AccessibleName = "-"
        Me.Label73.Location = New System.Drawing.Point(19, 384)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(76, 19)
        Me.Label73.TabIndex = 234
        Me.Label73.Text = "フリガナ"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label74
        '
        Me.Label74.AccessibleName = "-"
        Me.Label74.Location = New System.Drawing.Point(19, 408)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(76, 19)
        Me.Label74.TabIndex = 235
        Me.Label74.Text = "住所１"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(101, 408)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(336, 19)
        Me.TextBox62.TabIndex = 236
        '
        'Label75
        '
        Me.Label75.AccessibleName = "-"
        Me.Label75.Location = New System.Drawing.Point(19, 456)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(76, 19)
        Me.Label75.TabIndex = 238
        Me.Label75.Text = "住所２"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label76
        '
        Me.Label76.AccessibleName = "-"
        Me.Label76.Location = New System.Drawing.Point(19, 432)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(76, 19)
        Me.Label76.TabIndex = 237
        Me.Label76.Text = "フリガナ"
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(101, 456)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(411, 19)
        Me.TextBox63.TabIndex = 240
        '
        'TextBox64
        '
        Me.TextBox64.Location = New System.Drawing.Point(101, 432)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(411, 19)
        Me.TextBox64.TabIndex = 239
        '
        'Label13
        '
        Me.Label13.AccessibleName = "-"
        Me.Label13.Location = New System.Drawing.Point(435, 190)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(20, 19)
        Me.Label13.TabIndex = 256
        Me.Label13.Text = "満"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AccessibleName = "-"
        Me.Label14.Location = New System.Drawing.Point(359, 189)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(70, 19)
        Me.Label14.TabIndex = 256
        Me.Label14.Text = "年齢"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(457, 189)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(39, 19)
        Me.TextBox8.TabIndex = 257
        '
        'Label15
        '
        Me.Label15.AccessibleName = "-"
        Me.Label15.Location = New System.Drawing.Point(498, 190)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(20, 19)
        Me.Label15.TabIndex = 258
        Me.Label15.Text = "歳"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(201, 285)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(70, 19)
        Me.TextBox50.TabIndex = 259
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(190, 336)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(77, 19)
        Me.TextBox51.TabIndex = 260
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(302, 285)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(70, 19)
        Me.TextBox59.TabIndex = 263
        '
        'Label115
        '
        Me.Label115.AccessibleName = "-"
        Me.Label115.Location = New System.Drawing.Point(19, 603)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(61, 18)
        Me.Label115.TabIndex = 266
        Me.Label115.Text = "配偶者"
        Me.Label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox33
        '
        Me.ComboBox33.FormattingEnabled = True
        Me.ComboBox33.Location = New System.Drawing.Point(85, 601)
        Me.ComboBox33.Name = "ComboBox33"
        Me.ComboBox33.Size = New System.Drawing.Size(47, 20)
        Me.ComboBox33.TabIndex = 265
        '
        'GroupBox2
        '
        Me.GroupBox2.BackgroundImage = CType(resources.GetObject("GroupBox2.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox2.Controls.Add(Me.TextBox79)
        Me.GroupBox2.Controls.Add(Me.Label129)
        Me.GroupBox2.Controls.Add(Me.TextBox68)
        Me.GroupBox2.Controls.Add(Me.Label127)
        Me.GroupBox2.Controls.Add(Me.Label117)
        Me.GroupBox2.Controls.Add(Me.TextBox69)
        Me.GroupBox2.Controls.Add(Me.ComboBox34)
        Me.GroupBox2.Controls.Add(Me.Label126)
        Me.GroupBox2.Controls.Add(Me.TextBox65)
        Me.GroupBox2.Controls.Add(Me.ComboBox37)
        Me.GroupBox2.Controls.Add(Me.Label125)
        Me.GroupBox2.Controls.Add(Me.Label119)
        Me.GroupBox2.Controls.Add(Me.Label118)
        Me.GroupBox2.Controls.Add(Me.Label124)
        Me.GroupBox2.Controls.Add(Me.Label120)
        Me.GroupBox2.Controls.Add(Me.Label123)
        Me.GroupBox2.Controls.Add(Me.ComboBox35)
        Me.GroupBox2.Controls.Add(Me.ComboBox36)
        Me.GroupBox2.Controls.Add(Me.Label121)
        Me.GroupBox2.Controls.Add(Me.TextBox67)
        Me.GroupBox2.Controls.Add(Me.Label122)
        Me.GroupBox2.Controls.Add(Me.TextBox66)
        Me.GroupBox2.Location = New System.Drawing.Point(19, 628)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(493, 115)
        Me.GroupBox2.TabIndex = 202
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "配偶者情報"
        '
        'TextBox79
        '
        Me.TextBox79.Location = New System.Drawing.Point(89, 84)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(234, 19)
        Me.TextBox79.TabIndex = 180
        '
        'Label129
        '
        Me.Label129.AccessibleName = "-"
        Me.Label129.Location = New System.Drawing.Point(19, 85)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(64, 18)
        Me.Label129.TabIndex = 420
        Me.Label129.Text = "マイナンバー"
        Me.Label129.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox68
        '
        Me.TextBox68.Location = New System.Drawing.Point(89, 18)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(132, 19)
        Me.TextBox68.TabIndex = 400
        '
        'Label127
        '
        Me.Label127.AccessibleName = "-"
        Me.Label127.Location = New System.Drawing.Point(89, 39)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(20, 19)
        Me.Label127.TabIndex = 397
        Me.Label127.Text = "姓"
        Me.Label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label117
        '
        Me.Label117.AccessibleName = "-"
        Me.Label117.Location = New System.Drawing.Point(410, 63)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(20, 19)
        Me.Label117.TabIndex = 416
        Me.Label117.Text = "歳"
        Me.Label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox69
        '
        Me.TextBox69.Location = New System.Drawing.Point(113, 39)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(108, 19)
        Me.TextBox69.TabIndex = 401
        '
        'ComboBox34
        '
        Me.ComboBox34.FormattingEnabled = True
        Me.ComboBox34.Location = New System.Drawing.Point(437, 40)
        Me.ComboBox34.Name = "ComboBox34"
        Me.ComboBox34.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox34.TabIndex = 413
        '
        'Label126
        '
        Me.Label126.AccessibleName = "-"
        Me.Label126.Location = New System.Drawing.Point(19, 41)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(64, 18)
        Me.Label126.TabIndex = 402
        Me.Label126.Text = "氏名"
        Me.Label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox65
        '
        Me.TextBox65.Location = New System.Drawing.Point(366, 63)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(38, 19)
        Me.TextBox65.TabIndex = 415
        '
        'ComboBox37
        '
        Me.ComboBox37.FormattingEnabled = True
        Me.ComboBox37.Location = New System.Drawing.Point(226, 61)
        Me.ComboBox37.Name = "ComboBox37"
        Me.ComboBox37.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox37.TabIndex = 398
        '
        'Label125
        '
        Me.Label125.AccessibleName = "-"
        Me.Label125.Location = New System.Drawing.Point(224, 39)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(20, 19)
        Me.Label125.TabIndex = 404
        Me.Label125.Text = "名"
        Me.Label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label119
        '
        Me.Label119.AccessibleName = "-"
        Me.Label119.Location = New System.Drawing.Point(296, 63)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(64, 18)
        Me.Label119.TabIndex = 414
        Me.Label119.Text = "年齢"
        Me.Label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label118
        '
        Me.Label118.AccessibleName = "-"
        Me.Label118.Location = New System.Drawing.Point(376, 41)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(56, 19)
        Me.Label118.TabIndex = 412
        Me.Label118.Text = "性別"
        Me.Label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label124
        '
        Me.Label124.AccessibleName = "-"
        Me.Label124.Location = New System.Drawing.Point(130, 62)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(20, 19)
        Me.Label124.TabIndex = 405
        Me.Label124.Text = "年"
        Me.Label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label120
        '
        Me.Label120.AccessibleName = "-"
        Me.Label120.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label120.Location = New System.Drawing.Point(270, 62)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(20, 19)
        Me.Label120.TabIndex = 411
        Me.Label120.Text = "日"
        Me.Label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label123
        '
        Me.Label123.AccessibleName = "-"
        Me.Label123.Location = New System.Drawing.Point(19, 19)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(64, 18)
        Me.Label123.TabIndex = 399
        Me.Label123.Text = "フリガナ"
        Me.Label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox35
        '
        Me.ComboBox35.FormattingEnabled = True
        Me.ComboBox35.Location = New System.Drawing.Point(156, 61)
        Me.ComboBox35.Name = "ComboBox35"
        Me.ComboBox35.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox35.TabIndex = 410
        '
        'ComboBox36
        '
        Me.ComboBox36.FormattingEnabled = True
        Me.ComboBox36.Location = New System.Drawing.Point(89, 61)
        Me.ComboBox36.Name = "ComboBox36"
        Me.ComboBox36.Size = New System.Drawing.Size(38, 20)
        Me.ComboBox36.TabIndex = 406
        '
        'Label121
        '
        Me.Label121.AccessibleName = "-"
        Me.Label121.Location = New System.Drawing.Point(200, 62)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(20, 19)
        Me.Label121.TabIndex = 409
        Me.Label121.Text = "月"
        Me.Label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox67
        '
        Me.TextBox67.Location = New System.Drawing.Point(224, 18)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(138, 19)
        Me.TextBox67.TabIndex = 403
        '
        'Label122
        '
        Me.Label122.AccessibleName = "-"
        Me.Label122.Location = New System.Drawing.Point(19, 62)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(64, 18)
        Me.Label122.TabIndex = 408
        Me.Label122.Text = "生年月日"
        Me.Label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox66
        '
        Me.TextBox66.Location = New System.Drawing.Point(249, 39)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(113, 19)
        Me.TextBox66.TabIndex = 407
        '
        'Label128
        '
        Me.Label128.AccessibleName = "-"
        Me.Label128.Location = New System.Drawing.Point(11, 19)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(64, 18)
        Me.Label128.TabIndex = 179
        Me.Label128.Text = "マイナンバー"
        Me.Label128.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox70
        '
        Me.TextBox70.Location = New System.Drawing.Point(81, 18)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(225, 19)
        Me.TextBox70.TabIndex = 178
        '
        'GroupBox3
        '
        Me.GroupBox3.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.k_grid02_14
        Me.GroupBox3.Controls.Add(Me.Label128)
        Me.GroupBox3.Controls.Add(Me.TextBox70)
        Me.GroupBox3.Location = New System.Drawing.Point(19, 228)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(322, 46)
        Me.GroupBox3.TabIndex = 202
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "その他個人情報"
        '
        'Label114
        '
        Me.Label114.AccessibleName = "-"
        Me.Label114.Location = New System.Drawing.Point(138, 603)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(61, 18)
        Me.Label114.TabIndex = 269
        Me.Label114.Text = "扶養義務"
        Me.Label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox38
        '
        Me.ComboBox38.FormattingEnabled = True
        Me.ComboBox38.Location = New System.Drawing.Point(204, 601)
        Me.ComboBox38.Name = "ComboBox38"
        Me.ComboBox38.Size = New System.Drawing.Size(47, 20)
        Me.ComboBox38.TabIndex = 268
        '
        'ComboBox39
        '
        Me.ComboBox39.FormattingEnabled = True
        Me.ComboBox39.Location = New System.Drawing.Point(206, 189)
        Me.ComboBox39.Name = "ComboBox39"
        Me.ComboBox39.Size = New System.Drawing.Size(40, 20)
        Me.ComboBox39.TabIndex = 271
        '
        'Label138
        '
        Me.Label138.AccessibleName = "-"
        Me.Label138.Location = New System.Drawing.Point(1102, 19)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(95, 18)
        Me.Label138.TabIndex = 272
        Me.Label138.Text = "最終更新日時"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label139
        '
        Me.Label139.AccessibleName = "-"
        Me.Label139.Location = New System.Drawing.Point(759, 19)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(95, 18)
        Me.Label139.TabIndex = 273
        Me.Label139.Text = "当日の日付"
        Me.Label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(454, 17)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 23)
        Me.Button1.TabIndex = 274
        Me.Button1.Text = "←前へ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(549, 17)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 23)
        Me.Button2.TabIndex = 275
        Me.Button2.Text = "次へ→"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form_companion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.k_grid02_23
        Me.ClientSize = New System.Drawing.Size(1215, 1062)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label139)
        Me.Controls.Add(Me.Label138)
        Me.Controls.Add(Me.ComboBox39)
        Me.Controls.Add(Me.Label114)
        Me.Controls.Add(Me.ComboBox38)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label115)
        Me.Controls.Add(Me.ComboBox33)
        Me.Controls.Add(Me.TextBox59)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox50)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox63)
        Me.Controls.Add(Me.TextBox64)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.TextBox62)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.TextBox61)
        Me.Controls.Add(Me.GroupBox_bankinfo)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.ComboBox23)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.TextBox57)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.TextBox56)
        Me.Controls.Add(Me.TextBox55)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.TextBox54)
        Me.Controls.Add(Me.TextBox53)
        Me.Controls.Add(Me.TextBox52)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label_dependents)
        Me.Controls.Add(Me.ComboBox_dependents)
        Me.Controls.Add(Me.GroupBox_dependents)
        Me.Controls.Add(Me.Button_pictselect)
        Me.Controls.Add(Me.Label_retire)
        Me.Controls.Add(Me.Label_belong)
        Me.Controls.Add(Me.TextBox_belong)
        Me.Controls.Add(Me.Label_joindate)
        Me.Controls.Add(Me.TextBox_joindate)
        Me.Controls.Add(Me.TextBox_retire)
        Me.Controls.Add(Me.Label_company)
        Me.Controls.Add(Me.TextBox_Company)
        Me.Controls.Add(Me.PictureBox)
        Me.Controls.Add(Me.Button_delete)
        Me.Controls.Add(Me.Button_update)
        Me.Controls.Add(Me.Button_insert)
        Me.Controls.Add(Me.Button_select)
        Me.Controls.Add(Me.TextBox_address1kana)
        Me.Controls.Add(Me.ComboBox_Pref)
        Me.Controls.Add(Me.ComboBox_sex)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button_pictupload)
        Me.Controls.Add(Me.TextBox_lastnamekana)
        Me.Controls.Add(Me.Label_lastname)
        Me.Controls.Add(Me.Label_lastupdate)
        Me.Controls.Add(Me.Label_nowdate)
        Me.Controls.Add(Me.TextBox_empnum)
        Me.Controls.Add(Me.Label_empnum)
        Me.Controls.Add(Me.TextBox_birthyear)
        Me.Controls.Add(Me.ComboBox_nengou)
        Me.Controls.Add(Me.TextBox_telnumber1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "Form_companion"
        Me.Text = "社交データ"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox_bankinfo.ResumeLayout(False)
        Me.GroupBox_bankinfo.PerformLayout()
        Me.GroupBox_dependents.ResumeLayout(False)
        Me.GroupBox_dependents.PerformLayout()
        CType(Me.PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label_dependents As System.Windows.Forms.Label
    Friend WithEvents ComboBox_dependents As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label_accounttype As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox_branchname As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_bankname As System.Windows.Forms.TextBox
    Friend WithEvents Label_bankname As System.Windows.Forms.Label
    Friend WithEvents GroupBox_bankinfo As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_dependents As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Button_pictselect As System.Windows.Forms.Button
    Friend WithEvents Label_retire As System.Windows.Forms.Label
    Friend WithEvents Label_belong As System.Windows.Forms.Label
    Friend WithEvents TextBox_belong As System.Windows.Forms.TextBox
    Friend WithEvents Label_joindate As System.Windows.Forms.Label
    Friend WithEvents TextBox_joindate As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_retire As System.Windows.Forms.TextBox
    Friend WithEvents Label_company As System.Windows.Forms.Label
    Friend WithEvents TextBox_Company As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Button_delete As System.Windows.Forms.Button
    Friend WithEvents Button_update As System.Windows.Forms.Button
    Friend WithEvents Button_insert As System.Windows.Forms.Button
    Friend WithEvents Button_select As System.Windows.Forms.Button
    Friend WithEvents TextBox_address1kana As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox_Pref As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_sex As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button_pictupload As System.Windows.Forms.Button
    Friend WithEvents TextBox_lastnamekana As System.Windows.Forms.TextBox
    Friend WithEvents Label_lastname As System.Windows.Forms.Label
    Friend WithEvents Label_lastupdate As System.Windows.Forms.Label
    Friend WithEvents Label_nowdate As System.Windows.Forms.Label
    Friend WithEvents TextBox_empnum As System.Windows.Forms.TextBox
    Friend WithEvents Label_empnum As System.Windows.Forms.Label
    Friend WithEvents TextBox_birthyear As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox_nengou As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox_telnumber1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents ComboBox23 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents ComboBox33 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox34 As System.Windows.Forms.ComboBox
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox37 As System.Windows.Forms.ComboBox
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents ComboBox35 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox36 As System.Windows.Forms.ComboBox
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents ComboBox38 As System.Windows.Forms.ComboBox
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents TextBox78 As System.Windows.Forms.TextBox
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents ComboBox19 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents ComboBox20 As System.Windows.Forms.ComboBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox21 As System.Windows.Forms.ComboBox
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents ComboBox24 As System.Windows.Forms.ComboBox
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents ComboBox25 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents ComboBox26 As System.Windows.Forms.ComboBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox27 As System.Windows.Forms.ComboBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents ComboBox28 As System.Windows.Forms.ComboBox
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents ComboBox29 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents ComboBox30 As System.Windows.Forms.ComboBox
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox31 As System.Windows.Forms.ComboBox
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents ComboBox32 As System.Windows.Forms.ComboBox
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents ComboBox15 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents ComboBox16 As System.Windows.Forms.ComboBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox17 As System.Windows.Forms.ComboBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents ComboBox18 As System.Windows.Forms.ComboBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents ComboBox11 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents ComboBox12 As System.Windows.Forms.ComboBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox13 As System.Windows.Forms.ComboBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents ComboBox14 As System.Windows.Forms.ComboBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents ComboBox8 As System.Windows.Forms.ComboBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox9 As System.Windows.Forms.ComboBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ComboBox10 As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TextBox79 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox39 As System.Windows.Forms.ComboBox
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
